import React from "react";
import moment from "moment";

export default function ProveedoresListado({
  Items,
  RegistrosTotal,
  setAccionABMC,
}) {
  return (
    <div className="table-responsive">
      <table className="table table-hover table-sm table-bordered table-striped">
        <thead>
          <tr>
            <th className="text-center">Razon Social</th>
            <th className="text-center">Telefono</th>
            <th className="text-center">Fecha Alta</th>
          </tr>
        </thead>
        <tbody>
          {Items &&
            Items.map((proveedor) => (
              <tr key={proveedor.IdProveedor}>
                <td className="text-center">{proveedor.RazonSocial}</td>
                <td className="text-center">{proveedor.Telefono}</td>
                <td className="text-center">
                  {moment(proveedor.FechaAlta).format("DD/MM/YYYY")}
                </td>
               
              </tr>
            ))}
        </tbody>
      </table>

      {/* RegistrosTotal*/}
      <div className="paginador">
        <div className="row">
          <div className="col">
            <span className="pyBadge">Registros: {RegistrosTotal}</span>
          </div>
        </div>
      </div>
      <div className="row justify-content-center">
          <div className="col text-center botones">
            <button type="button" className="btn btn-secondary" onClick={() => setAccionABMC("A")}>
                Agregar
            </button>
          </div>
      </div>
    </div>
    
  );
}
