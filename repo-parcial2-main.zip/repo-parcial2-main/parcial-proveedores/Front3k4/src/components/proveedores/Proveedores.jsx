import React, { useState, useEffect } from "react";
import ProveedoresListado from "./ProveedoresListado";
import ProveedoresRegistro from "./ProveedoresRegistro";
import { proveedoresService } from "../../services/proveedores.service";
import { useNavigate } from 'react-router-dom';


function Proveedores() {
  const TituloAccionABMC = {
    A: "(Agregar)",
    L: "(Listado)",
  };
  const [AccionABMC, setAccionABMC] = useState("L");
  const navigate = useNavigate();

  const [Items, setItems] = useState(null);
  const [Item, setItem] = useState(null); // usado en BuscarporId (Modificar, Consultar)
  const [RegistrosTotal, setRegistrosTotal] = useState(0);

  async function Buscar() {
    const data = await proveedoresService.Buscar();
    setItems(data.Items);
    setRegistrosTotal(data.RegistrosTotal);
    setAccionABMC("L");
  }

  async function Grabar(proveedor) {
    try {
      await proveedoresService.Grabar(proveedor);
    }
    catch (error) {
      alert(error?.response?.data?.message ?? error.toString())
      return;
    }
    await Buscar();

    setTimeout(() => {
      alert(
        "Registro agregado correctamente."
      );
    }, 0);
  }

  function Volver() {
    navigate('/');
  }

  function AgregarProveedor() {
    setAccionABMC("A")
  }

  useEffect(() => {
    Buscar();
  }, []);

  return (
    <div>
      <div className="tituloPagina">
        Proveedores <small>{TituloAccionABMC[AccionABMC]}</small>
      </div>

      { AccionABMC === "L" && Items?.length > 0 && 
        <ProveedoresListado
          {...{
            Items,
            RegistrosTotal,
            setAccionABMC
          }}
        />
      }

      { AccionABMC === "A" && <ProveedoresRegistro
        {...{ AccionABMC, setAccionABMC, Item, Grabar, Volver }}
      />
      }

      { AccionABMC === "L" && Items?.length === 0 &&
        <div className="alert alert-info mensajesAlert">
          <i className="fa fa-exclamation-sign"></i>
          No se encontraron registros...
        </div>
      }
    </div>
  );
}

export { Proveedores }
