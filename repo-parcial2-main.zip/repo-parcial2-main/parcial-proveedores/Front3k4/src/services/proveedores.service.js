import axios from "axios";
const urlResource = "http://localhost:4000/api/proveedores";

async function Buscar() {
    try {
        const resp = await axios.get(urlResource);
        return resp.data;
    } catch (error) {
        throw error;
    }
}


async function Grabar(proveedor) {
  try {
    await axios.post(urlResource, proveedor);
  } catch (error) {
    throw error;
  }
}


export const proveedoresService = {
  Buscar,Grabar
};
