const urlServidor = "http://localhost:3001"
//const urlServidor = "https://labsys.frc.utn.edu.ar/dds-express"
const urlResourceObras = urlServidor + "/api/obras-teatrales";
const urlResourceClasificaciones = urlServidor + "/api/clasificaciones";


export const config = {
    urlServidor,
    urlResourceObras,
    urlResourceClasificaciones
    
}
