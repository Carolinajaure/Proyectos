import { config } from "../config";
import httpService from "./http.service";

const urlResource = "/api/obras-teatrales";

async function Buscar() {
    try {
      const resp = await httpService.get(urlResource);
      return resp.data;
    } catch (error) {
      throw error;
    }
  };
  
  
  async function Grabar(obra) {
    try {
      const resp = await httpService.post(urlResource, obra);
      return resp.data;
    } catch (error) {
      throw error;
    }
  };
  
  
  
  
  export const obrasteatralesService = {
    Buscar,Grabar
  };
  
  