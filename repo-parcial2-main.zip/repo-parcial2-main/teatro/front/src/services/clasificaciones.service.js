
import httpService from "./http.service";
const urlResource = "/api/clasificaciones";

async function Buscar() {
  try {
    const resp = await httpService.get(urlResource);
    return resp.data;
  } catch (error) {
    throw error;
  }
};


export const clasificacionesService = {
  Buscar
};

