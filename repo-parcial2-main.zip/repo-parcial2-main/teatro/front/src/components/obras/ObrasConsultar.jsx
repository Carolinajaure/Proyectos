import React, {useState, useEffect} from 'react';
import { useNavigate } from 'react-router-dom';
import { obrasteatralesService } from '../../services/obras.service';


function Consultar() {
    const tituloPagina = 'Obras Teatrales';
    const [obrasTeatrales, setObrasTeatrales] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const BuscarObrasTeatrales = async () => {
            try {
                let data = await obrasteatralesService.Buscar();
                setObrasTeatrales(data);
            } catch (error){
                console.error("Hubo un error recuperando las obras: ", error);
            }
        };
        BuscarObrasTeatrales();
      }, []);

  return (
    <div>
         <button type='button' className="btn btn-primary" onClick={() => navigate('/consultar')}>Consultar</button>
        <div className="tituloPagina">{tituloPagina}</div>
        <table className="table table-bordered table-striped">
            <thead>
            <tr>
                <th scope='col' className="text-center">ID</th>
                <th scope='col' className="text-center">Titulo</th>
                <th scope='col' className="text-center">Director</th>
                <th scope='col' className="text-center">Clasificacion</th>
            </tr>
            </thead>
            <tbody>
                {obrasTeatrales.map(obra => (
                <tr key={obra.id}>
                    <td>{obra.id}</td>
                    <td>{obra.titulo}</td>
                    <td>{obra.director}</td>
                    <td>{obra.clasificacion.titulo}</td>
                </tr>
                ))}
            </tbody>
        </table>
       
    </div>
  );
}


export { Consultar };
