import React from "react";
import { useForm } from "react-hook-form";
import { obrasteatralesService } from '../../services/obras.service';
import { useState, useEffect } from "react";
import { clasificacionesService } from "../../services/clasificaciones.service";


export default function Registrar() {
    async function Grabar(item) {
        // agregar o modificar
        try
        {
          await obrasteatralesService.Grabar(item);
        }
        catch (error)
        {
          alert(error?.response?.data?.message ?? error.toString())
          return;
        }
      
        setTimeout(() => {
          alert(
            "Registro agregado correctamente"
          );
        }, 0);
      }

  const [clasificaciones, setClasificaciones] = useState(null);

  useEffect(() => {
    const BuscarClasificaciones = async () => {
      try {
        let data = await clasificacionesService.Buscar();
        setClasificaciones(data);
      } catch (error) {
        console.error("Hubo un error recuperando las clasificaciones: ", error);
      }
    }  
    BuscarClasificaciones();
  }, []);
 

  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields, isValid, isSubmitted },
  } = useForm();

  const onSubmit = (data) => {
    
    Grabar(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="container-fluid">

        <fieldset>

          {/* campo nombre */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="titulo">
                Titulo<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
            <input
              type="text"
              {...register("titulo", {
                required: { value: true, message: "El nombre de la obra es requerido" },
              })}
              autoFocus
              className={
                "form-control " + (errors?.titulo ? "is-invalid" : "")
              }
            />
            {errors?.titulo && touchedFields.titulo && (
              <div className="invalid-feedback">
                {errors?.titulo?.message}
              </div>
            )}
            </div>
          </div>
          
          {/* campo director */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="director">
                Director<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
            <input
              type="text"
              {...register("director", {
                required: { value: true, message: "El director de la obra es requerido" },
              })}
              autoFocus
              className={
                "form-control " + (errors?.director ? "is-invalid" : "")
              }
            />
            {errors?.director && touchedFields.director && (
              <div className="invalid-feedback">
                {errors?.director?.message}
              </div>
            )}
            </div>
          </div>

          {/* campo clasificación */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="idClasificacion">
                Clasificación<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
            <select
              {...register("idClasificacion", {
                required: { value: true, message: "Clasificacion es requerido" },
              })}
              className={
                "form-control " +
                (errors?.idClasificacion ? "is-invalid" : "")
              }
            >
              <option value="" key={1}></option>
              {clasificaciones?.map((x) => (
                <option value={x.id} key={x.id}>
                  {x.titulo}
                </option>
              ))}
            </select>
            <div className="invalid-feedback">
              {errors?.idClasificacion?.message}
            </div>
            </div>
          </div>

        </fieldset>

        {/* Botones Grabar, Cancelar/Volver' */}
        <hr />
        <div className="row justify-content-center">
          <div className="col text-center botones">
              <button type="submit" className="btn btn-primary">
                <i className="fa fa-check"></i> Grabar
              </button>
          </div>
        </div>

        {/* texto: Revisar los datos ingresados... */}
        {!isValid && isSubmitted && (
          <div className="row alert alert-danger mensajesAlert">
            <i className="fa fa-exclamation-sign"></i>
            Revisar los datos ingresados...
          </div>
        )}

      </div>
    </form>
  );
}

export { Registrar };
