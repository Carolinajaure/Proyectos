import React from "react";
import { NavLink } from "react-router-dom";


function Menu() {
  return (
    <nav className="navbar navbar-dark bg-dark navbar-expand-md">
      <a className="navbar-brand" href="#!">
        
      </a>
      <button
        className="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>
    
      <ul className="navbar-nav ml-auto">
        <li className="nav-item">
          <NavLink className="nav-link" to="/consultar">
            Obras Teatrales
          </NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link" to="/registrar">
            Crear Obra Teatral
          </NavLink>
        </li>
      </ul>
    </nav>
  );
}


export { Menu };
