import "./App.css";
import { BrowserRouter, Route, Routes} from "react-router-dom";
import { Consultar } from "./components/obras/ObrasConsultar";
import { Menu } from "./components/Menu";
import { Registrar } from "./components/obras/ObrasRegistro";


function App() {
  return (
    <>
      <BrowserRouter>
        <Menu />
        <div className="divBody">
        
            <Routes>
            
              
              <Route path="/registrar" element={<Registrar/>} />
              
            </Routes>
            <Consultar />
        </div>
      </BrowserRouter>
    </>
  );
}


export default App;
