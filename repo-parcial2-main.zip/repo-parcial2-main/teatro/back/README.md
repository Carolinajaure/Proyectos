# Ejercicio Integrador Desarrollo de Software 3K2

## Presentacion

https://docs.google.com/presentation/d/1nbGw7ijOw4k4OpwwifDg9MVFIpo1y-775LmwYxp98cE/edit?usp=sharing

## Configuracion inicial para la actividad

Clonar repositorio: https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/proyectos/3k2/tests-middlewares-cine-extendido   

RAMA: base-test-mid-cine-extendido

```
$ git clone <URL-REPO>
$ cd REPO
$ git branch
$ git checkout -b <LEGAJO>-clase-15-test-mid-cine-extendido
```


## Enunciado
- Generar los controllers para los endpoinds (`GET, POST, PUT, DELETE`) de funciones y salas
- Generar los test para los endpoints de funciones y salas
- Verificar que los test se ejecuta ok.
- Pushear rama a repositorio.
