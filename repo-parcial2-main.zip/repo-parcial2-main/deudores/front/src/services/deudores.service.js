import axios from "axios";
const urlResource = "http://localhost:4000/api/deudores";

async function Buscar() {
    try {
        const resp = await axios.get(urlResource);
        return resp.data;
    } catch (error) {
        throw error;
    }
}


async function Grabar(deudor) {
  try {
    await axios.post(urlResource, deudor);
  } catch (error) {
    throw error;
  }
}


export const deudoresService = {
  Buscar,Grabar
};
