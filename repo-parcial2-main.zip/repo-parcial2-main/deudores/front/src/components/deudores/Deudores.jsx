import React, { useState, useEffect } from "react";
import DeudoresListado from "./DeudoresListado";
import DeudoresRegistro from "./DeudoresRegistro";
import { deudoresService } from "../../services/deudores.service";
import { useNavigate } from 'react-router-dom';


function Deudores() {
  const TituloAccionABMC = {
    A: "(Agregar)",
    L: "(Listado)",
  };
  const [AccionABMC, setAccionABMC] = useState("L");
  const navigate = useNavigate();

  // const [ApellidoYNombre, setApellidoYNombre] = useState("");
  // const [Suspendido, setSuspendido] = useState("");

  const [Items, setItems] = useState(null);
  const [Item, setItem] = useState(null); // usado en BuscarporId (Modificar, Consultar)
  const [RegistrosTotal, setRegistrosTotal] = useState(0);

  // cargar al "montar" el componente, solo la primera vez (por la dependencia [])

  async function Buscar() {
    const data = await deudoresService.Buscar();
    setItems(data.Items);
    setRegistrosTotal(data.RegistrosTotal);
    setAccionABMC("L");
    }

  /*async function BuscarPorId(item, accionABMC) {
    const data = await deudoresService.BuscarPorId(item);
    setItem(data);
    setAccionABMC(accionABMC);
  }*/

  
  async function Grabar(deudor) {
  // agregar o modificar
  try {
    await deudoresService.Grabar(deudor);
  }
  catch (error) {
    alert(error?.response?.data?.message ?? error.toString())
    return;
  }
  await Buscar();

  setTimeout(() => {
    alert(
      "Registro agregado correctamente."
    );
  }, 0);
}


  // Volver/Cancelar desde Agregar/Modificar/Consultar
  function Volver() {
    navigate('/');
  }

  function AgregarDeudor() {
    setAccionABMC("A")
  }

  useEffect(() => {
    Buscar();
  }, []);

  return (
    <div>
      <div className="tituloPagina">
        Deudores <small>{TituloAccionABMC[AccionABMC]}</small>
      </div>

      {/* Tabla de resutados de busqueda y Paginador */}
      { AccionABMC === "L" && Items?.length > 0 && 
        <DeudoresListado
            {...{
            Items,
            RegistrosTotal,
            setAccionABMC
            }}
        />
      }

      {/* Formulario de alta/modificacion/consulta */}
      { AccionABMC === "A" && <DeudoresRegistro
        {...{ AccionABMC, setAccionABMC, Item, Grabar, Volver }}
      />
      }

      { AccionABMC === "L" && Items?.length === 0 &&
        <div className="alert alert-info mensajesAlert">
            <i className="fa fa-exclamation-sign"></i>
            No se encontraron registros...
        </div>
      }
    </div>
  );
}

export { Deudores }