import React from "react";
import moment from "moment";

export default function DeudoresListado({
  Items,
  RegistrosTotal,
  setAccionABMC,
}) {
  return (
    <div className="table-responsive">
      <table className="table table-hover table-sm table-bordered table-striped">
        <thead>
          <tr>
            <th className="text-center">Apellido y Nombre</th>
            <th className="text-center">Fecha deuda</th>
            <th className="text-center">Importe</th>
          </tr>
        </thead>
        <tbody>
          {Items &&
            Items.map((deudor) => (
              <tr key={deudor.IdDeudor}>
                <td className="text-center">{deudor.ApellidoYNombre}</td>
                <td className="text-center">
                  {moment(deudor.FechaDeuda).format("DD/MM/YYYY")}
                </td>
                <td className="text-center">${deudor.ImporteAdeudado}</td>
              </tr>
            ))}
        </tbody>
      </table>

      {/* RegistrosTotal*/}
      <div className="paginador">
        <div className="row">
          <div className="col">
            <span className="pyBadge">Registros: {RegistrosTotal}</span>
          </div>
        </div>
      </div>
      <div className="row justify-content-center">
          <div className="col text-center botones">
            <button type="button" className="btn btn-secondary" onClick={() => setAccionABMC("A")}>
                Agregar
            </button>
          </div>
      </div>
    </div>
    
  );
}
