// Importar los módulos necesarios
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors'); // Importar cors

// Crear la aplicación Express
const app = express();

// Configurar body-parser como middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors({
    origin: '*' // Permitir cualquier origen
  }));

// Eliminar la base de datos existente si existe
const dbPath = './backend.db';
fs.unlinkSync(dbPath, { throwIfNoEntry: false });

// Crear una nueva base de datos
let db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error(err.message);
    }
    console.log('Connected to the backend database.');
});

// Crear la tabla de clientes
db.run(`CREATE TABLE clientes (
    id INTEGER PRIMARY KEY,
    documento TEXT,
    tipo_documento TEXT,
    nombre TEXT,
    apellido TEXT
)`, (err) => {
    if (err) {
        console.log(err.message);
    } else {
        // Insertar datos de ejemplo
        let stmt = db.prepare("INSERT INTO clientes (documento, tipo_documento, nombre, apellido) VALUES (?, ?, ?, ?)");
        for (let i = 0; i < 10; i++) {
            // Elegir al azar entre 'DNI' y 'LC'
            let tipo_documento = Math.random() < 0.5 ? 'DNI' : 'LC';
            stmt.run(`documento${i}`, tipo_documento, `nombre${i}`, `apellido${i}`);
        }
        stmt.finalize();
    }
});

// Obtener todos los clientes 
//app.get('/clientes', (req, res) => { db.all('SELECT * FROM clientes', (err, rows) => { if (err) { console.error(err.message); res.status(500).json({ error: 'Internal server error' }); } else { res.json(rows); } }); });


//busqueda de clientes por documento y tipo de documento
app.get('/clientes', (req, res) => {
    const documento = req.query.documento;
    const tipo_documento = req.query.tipo_documento;
    if (documento) {
        db.all('SELECT * FROM clientes WHERE documento = ?', [documento], (err, rows) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ error: 'Internal server error' });
            } else {
                res.json(rows);
            }
        });
    } else if (tipo_documento) {
        db.all('SELECT * FROM clientes WHERE tipo_documento = ?', [tipo_documento], (err, rows) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ error: 'Internal server error' });
            } else {
                res.json(rows);
            }
        });
    } else {
        db.all('SELECT * FROM clientes', (err, rows) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ error: 'Internal server error' });
            } else {
                res.json(rows);
            }
        });
    }
});

// Configurar la aplicación para escuchar en el puerto 3000
app.listen(3001, () => {
    console.log('Server is running on port 3001');
});

// Exportar la aplicación
module.exports = app;