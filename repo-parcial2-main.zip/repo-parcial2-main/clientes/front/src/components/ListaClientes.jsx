import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { clientesService } from '../services/clientes.service';

function ListaClientes() {
    const tituloPagina = 'Clientes';
    const [clientes, setClientes] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const buscarClientes = async () => {
            try {
                let data = await clientesService.Buscar();
                setClientes(data);
            } catch (error) {
                console.error('Hubo un error recuperando los clientes: ', error);
            }
        };
        buscarClientes();
    }, []);

    return (
        <div>
            <div className="tituloPagina">{tituloPagina}</div>
            <table className="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th scope="col" className="text-center">
                            ID
                        </th>
                        <th scope="col" className="text-center">
                            Documento
                        </th>
                        <th scope="col" className="text-center">
                            Tipo Documento
                        </th>
                        <th scope="col" className="text-center">
                            Nombre
                        </th>
                        <th scope="col" className="text-center">
                            Apellido
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {clientes.map(cliente => (
                        <tr key={cliente.id}>
                            <td>{cliente.id}</td>
                            <td>{cliente.documento}</td>
                            <td>{cliente.tipo_documento}</td>
                            <td>{cliente.nombre}</td>
                            <td>{cliente.apellido}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <button type="button" className="btn btn-secondary" onClick={() => navigate('/')}>
                Volver
            </button>
        </div>
    );
}

export { ListaClientes };
