import React from "react";
import { useForm } from "react-hook-form";
import { clientesService } from '../services/clientes.service';
import { useNavigate } from 'react-router-dom';



export default function Registrar() {
    const navigate = useNavigate();
    async function Grabar(item) {
        // agregar o modificar
        try
        {
          await clientesService.Grabar(item);
        }
        catch (error)
        {
          alert(error?.response?.data?.message ?? error.toString())
          return;
        }
      
        setTimeout(() => {
          alert(
            "Registro agregado correctamente"
          );
        }, 0);
      }


  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields, isValid, isSubmitted },
  } = useForm();

  const onSubmit = (data) => {
    Grabar(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="container-fluid">

        <fieldset>

          {/* campo documento */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="documento">
                Documento<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
            <input
              type="text"
              {...register("documento", {
                required: { value: true, message: "El documento es requerido" },
              })}
              autoFocus
              className={
                "form-control " + (errors?.documento ? "is-invalid" : "")
              }
            />
            {errors?.documento && touchedFields.documento && (
              <div className="invalid-feedback">
                {errors?.documento?.message}
              </div>
            )}
            </div>
          </div>
          
          {/* campo tipoDocumento */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="tipoDocumento">
                Tipo Documento<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
            <input
              type="text"
              {...register("tipoDocumento", {
                required: { value: true, message: "El tipoDocumento requerido" },
              })}
              autoFocus
              className={
                "form-control " + (errors?.tipoDocumento ? "is-invalid" : "")
              }
            />
            {errors?.tipoDocumento && touchedFields.tipoDocumento && (
              <div className="invalid-feedback">
                {errors?.tipoDocumento?.message}
              </div>
            )}
            </div>
          </div>

            {/* campo nombre */}
            <div className="row">
              <div className="col-sm-4 col-md-3 offset-md-1">
                <label className="col-form-label" htmlFor="nombre">
                  Nombre<span className="text-danger">*</span>:
                </label>
              </div>
              <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("nombre", {
                  required: { value: true, message: "El nombre es requerido" },
                })}
                autoFocus
                className={
                  "form-control " + (errors?.nombre ? "is-invalid" : "")
                }
              />
              {errors?.nombre && touchedFields.nombre && (
                <div className="invalid-feedback">
                  {errors?.nombre?.message}
                </div>
              )}
              </div>
            </div>
                
                {/* campo apellido */}
                <div className="row">
                  <div className="col-sm-4 col-md-3 offset-md-1">
                    <label className="col-form-label" htmlFor="apellido">
                      Apellido<span className="text-danger">*</span>:
                    </label>
                  </div>
                  <div className="col-sm-8 col-md-6">
                  <input
                    type="text"
                    {...register("apellido", {
                      required: { value: true, message: "El apellido es requerido" },
                    })}
                    autoFocus
                    className={
                      "form-control " + (errors?.apellido ? "is-invalid" : "")
                    }
                  />
                  {errors?.apellido && touchedFields.apellido && (
                    <div className="invalid-feedback">
                      {errors?.apellido?.message}
                    </div>
                  )}
                  </div>
                </div>

        </fieldset>

        {/* Botones Grabar, Cancelar/Volver' */}
        <hr />
        <div className="row justify-content-center">
          <div className="col text-center botones">
              <button type="submit" className="btn btn-primary">
                <i className="fa fa-check"></i> Grabar
              </button>
          </div>
        </div>
        <button type="button" className="btn btn-secondary" onClick={() => navigate('/')}>
                Volver
            </button>

        {/* texto: Revisar los datos ingresados... */}
        {!isValid && isSubmitted && (
          <div className="row alert alert-danger mensajesAlert">
            <i className="fa fa-exclamation-sign"></i>
            Revisar los datos ingresados...
          </div>
        )}

      </div>
    </form>
  );
}

export { Registrar };
