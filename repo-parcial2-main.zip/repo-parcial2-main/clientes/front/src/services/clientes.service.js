import { config } from "../config";
import httpService from "./http.service";

const urlResource = "/clientes";

async function Buscar() {
    try {
        const resp = await httpService.get(urlResource);
        return resp.data;
    } catch (error) {
        throw error;
    }
};


async function Grabar(cliente) {
    try {
        const resp = await httpService.post(urlResource, cliente);
        return resp.data;
    } catch (error) {
        throw error;
    }
};


export const clientesService = {
    Buscar,
    Grabar
};
