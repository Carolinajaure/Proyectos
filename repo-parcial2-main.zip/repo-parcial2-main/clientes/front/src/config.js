const urlServidor = "http://localhost:3001"
//const urlServidor = "https://labsys.frc.utn.edu.ar/dds-express"
const urlResourceClientes = urlServidor + "/clientes";



export const config = {
    urlServidor,
    urlResourceClientes,
   
    
}
