import "./App.css";
import { BrowserRouter, Route, Routes} from "react-router-dom";
import { ListaClientes } from "./components/ListaClientes";
import { Menu } from "./components/Menu";
import { Registrar } from "./components/Registrar";


function App() {
  return (
    <>
      <BrowserRouter>
        
        <div className="divBody">
            <Routes>
            
              <Route path="/lista" element={<ListaClientes />} />
              <Route path="/registro" element={<Registrar/>} />
              <Route path="/" element={<Menu />} />
              
            </Routes>
        </div>
      </BrowserRouter>
    </>
  );
}


export default App;
