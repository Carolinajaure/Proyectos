package com.example.tpi_Back.Entidades;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.List;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Table(name = "Vehiculos")
public class Vehiculo {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment" ,strategy = "increment")
    private Integer id;

    @Column(name = "PATENTE")
    private String patente;

    @Column(name = "ID_MODELO")
    private Integer id_modelo;

    @Column(name = "ANIO")
    private Integer anio;

    @OneToMany(mappedBy="vehiculo", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JsonIgnore
    private List<Posicion> posiciones;

    @ManyToOne
    @JoinColumn(name="ID_MODELO", insertable = false, updatable = false)
    private Modelo modelos;

    //Getters y Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public Integer getId_modelo() {
        return id_modelo;
    }

    public void setId_modelo(Integer id_modelo) {
        this.id_modelo = id_modelo;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public List<Posicion> getPosiciones() {
        return posiciones;
    }

    public void setPosiciones(List<Posicion> posiciones) {
        this.posiciones = posiciones;
    }

    public Modelo getModelos() {
        return modelos;
    }

    public void setModelos(Modelo modelos) {
        this.modelos = modelos;
    }

    //toString
    @Override
    public String toString() {
        return "Vehiculo{" +
                "id=" + id +
                ", patente='" + patente + '\'' +
                ", id_modelo=" + id_modelo +
                ", anio=" + anio +
                '}';
    }
}