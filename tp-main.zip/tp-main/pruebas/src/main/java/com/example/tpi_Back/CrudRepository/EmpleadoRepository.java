package com.example.tpi_Back.CrudRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;
import com.example.tpi_Back.Entidades.Empleado;
import org.springframework.data.repository.query.Param;

public interface EmpleadoRepository extends JpaRepository<Empleado, Integer> {
    @Query("SELECT e FROM Empleado e WHERE e.legajo = :legajo")
    Optional<Empleado> findById(@Param("legajo") Integer id);

}
