package com.example.tpi_Back.CrudRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.example.tpi_Back.Entidades.Interesado;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface InteresadoRepository extends JpaRepository<Interesado, Integer> {

    @Query("SELECT CASE WHEN COUNT(i) = 0 THEN true ELSE false END " +
            "FROM Interesado i " +
            "WHERE (i.fechaVencimientoLicencia < CURRENT_TIMESTAMP OR i.restringido = true) " +
            "AND i.id = :id")
    boolean buscarClienteConLicenciaVigenteYNoRestringido(@Param("id") Integer id);


    @Query("SELECT i FROM Interesado i WHERE i.id = :id")
    Optional<Interesado> findById(@Param("id") Integer id);
};

