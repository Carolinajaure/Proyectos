package com.example.tpi_Back.CrudRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;
import com.example.tpi_Back.Entidades.Vehiculo;
import org.springframework.data.repository.query.Param;

public interface VehiculoRepository extends JpaRepository<Vehiculo, Integer> {

@Query("SELECT v FROM Vehiculo v WHERE v.id = :id")
Optional<Vehiculo> findById(@Param("id") Integer id);

}