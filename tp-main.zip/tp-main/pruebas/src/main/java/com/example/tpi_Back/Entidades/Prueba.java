package com.example.tpi_Back.Entidades;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Table(name = "Pruebas")
public class Prueba {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment" ,strategy = "increment")
    private Integer id;

    @Column(name = "FECHA_HORA_INICIO")
    private LocalDateTime fecha_hora_inicio;

    @Column(name = "FECHA_HORA_FIN")
    private LocalDateTime fecha_hora_fin;

    @Column(name = "COMENTARIOS")
    private String comentarios;

    @ManyToOne
    @JoinColumn (name = "ID_EMPLEADO")
    private Empleado empleado;

    @ManyToOne
    @JoinColumn (name = "ID_VEHICULO")
    private Vehiculo vehiculo;

    @ManyToOne
    @JoinColumn (name = "ID_INTERESADO" ,nullable = false)
    private Interesado interesado;

    //Getters y Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDateTime getFecha_hora_inicio() {
        return fecha_hora_inicio;
    }

    public void setFecha_hora_inicio(LocalDateTime fecha_hora_inicio) {
        this.fecha_hora_inicio = fecha_hora_inicio;
    }

    public LocalDateTime getFecha_hora_fin() {
        return fecha_hora_fin;
    }

    public void setFecha_hora_fin(LocalDateTime fecha_hora_fin) {
        this.fecha_hora_fin = fecha_hora_fin;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public Interesado getInteresado() {
        return interesado;
    }

    public void setInteresado(Interesado interesado) {
        this.interesado = interesado;
    }

    //toString
    @Override
    public String toString() {
        return "Prueba{" +
                "id=" + id +
                ", fecha_hora_inicio=" + fecha_hora_inicio +
                ", fecha_hora_fin=" + fecha_hora_fin +
                ", comentarios='" + comentarios + '\'' +
                '}';
    }
}

