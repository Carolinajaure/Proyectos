package com.example.tpi_Back.Services;

import com.example.tpi_Back.CrudRepository.EmpleadoRepository;
import com.example.tpi_Back.CrudRepository.InteresadoRepository;
import com.example.tpi_Back.CrudRepository.PruebaRepository;
import com.example.tpi_Back.CrudRepository.VehiculoRepository;
import com.example.tpi_Back.Entidades.Empleado;
import com.example.tpi_Back.Entidades.Interesado;
import com.example.tpi_Back.Entidades.Prueba;
import com.example.tpi_Back.Entidades.Vehiculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class PruebasService {
    private PruebaRepository repositorioPrueba;
    private InteresadoRepository repositorioInteresado;
    private VehiculoRepository repositorioVehiculo;
    private EmpleadoRepository repositorioEmpleado;

    @Autowired
    public PruebasService(PruebaRepository repositorioPrueba, InteresadoRepository repositorioInteresado, VehiculoRepository repositorioVehiculo, EmpleadoRepository repositorioEmpleado) {
        this.repositorioPrueba = repositorioPrueba;
        this.repositorioInteresado = repositorioInteresado;
        this.repositorioVehiculo = repositorioVehiculo;
        this.repositorioEmpleado = repositorioEmpleado;
    }

    @Transactional
    public String crearPruebaSiVehiculoDisponible(Integer vehiculoId, Integer idInteresado,
                                                  String comentarios, Integer empleadoId) {

        Interesado interesado = (repositorioInteresado.findById(idInteresado)).orElse(null);
        if (interesado == null) {
            return "No se encontró el interesado";
        }

        Empleado empleado = (repositorioEmpleado.findById(empleadoId)).orElse(null);
        if (empleado == null) {
            return "No se encontró el empleado";
        }

        Vehiculo vehiculo = (repositorioVehiculo.findById(vehiculoId)).orElse(null);
        if (vehiculo == null) {
            return "No se encontró el vehículo";
        }

        if ((repositorioPrueba.existsVehiculoDisponible(vehiculoId)) &&
                (repositorioInteresado.buscarClienteConLicenciaVigenteYNoRestringido(idInteresado)) && repositorioPrueba.existsEmpleadoDisponible(empleadoId)
                    && repositorioPrueba.existsInteresadoDisponible(idInteresado)) {

            Prueba nuevaPrueba = new Prueba();
            nuevaPrueba.setComentarios(comentarios);
            nuevaPrueba.setFecha_hora_inicio(LocalDateTime.now());
            nuevaPrueba.setEmpleado(empleado);
            nuevaPrueba.setVehiculo(vehiculo);
            nuevaPrueba.setInteresado(interesado);

            repositorioPrueba.save(nuevaPrueba);
            return "Prueba creada";
        } else {
            return "No se pudo crear la prueba para el vehiculo: " + vehiculo + " el interesado: " + interesado + " y el empleado: " + empleado;
        }
    }

    @Transactional
    public List<Prueba> obtenerPruebasEnCurso() {
        return repositorioPrueba.findPruebasEnCurso();
    }

    @Transactional
    public List<Prueba> obtenerPruebas() {
        List<Prueba> pruebas = repositorioPrueba.findAll();
        System.out.println("Pruebas encontradas: " + pruebas);
        return pruebas;
    }

    @Transactional
    public String finalizarPrueba(Long pruebaId, String comentarioFinal) {
        Prueba prueba = repositorioPrueba.findByIdPrueba(pruebaId);
        if (prueba == null) {
            return "No se encontró la prueba";
        }

        prueba.setFecha_hora_fin(LocalDateTime.now());
        prueba.setComentarios(prueba.getComentarios() + " | Comentario final: " + comentarioFinal);
        repositorioPrueba.save(prueba);
        System.out.println("Finalizo la prueba con id: " + pruebaId);
        return "Prueba finalizada";
    }
}
