package com.example.tpi_Back.controllers;

import com.example.tpi_Back.Entidades.Prueba;
import com.example.tpi_Back.Services.PruebasService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/pruebas")
public class pruebaController {
    private final PruebasService service;

    @Autowired
    public pruebaController(PruebasService servicio) {
        this.service = servicio;
    }

    @PostMapping("/crear-prueba")
    public ResponseEntity<String> createPrueba(
            @RequestParam Integer vehiculoId,
            @RequestParam Integer idInteresado,
            @RequestParam String comentarios,
            @RequestParam Integer empleadoId) {
        String prueba = service.crearPruebaSiVehiculoDisponible(vehiculoId, idInteresado, comentarios, empleadoId);
        return ResponseEntity.ok(prueba);
    }

    @GetMapping("/pruebasActuales")
    public ResponseEntity<List<Prueba>> getPruebasFecha() {
            return ResponseEntity.ok(service.obtenerPruebasEnCurso());
    }

    @GetMapping("/todas")
    public ResponseEntity<List<Prueba>> getPruebas() {
        try {
            return ResponseEntity.ok(service.obtenerPruebas());
        } catch (Exception e) {
            System.err.println("Error al obtener las pruebas: " + e);
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/finalizar/{pruebaId}/{comentarioFinal}")
    public ResponseEntity<String> finalizarPrueba(
            @PathVariable Long pruebaId,
            @PathVariable String comentarioFinal) {
        String resultado = service.finalizarPrueba(pruebaId, comentarioFinal);
        return ResponseEntity.ok(resultado);
    }
}
