package com.example.tpi_Back.CrudRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import org.springframework.data.repository.query.Param;
import com.example.tpi_Back.Entidades.Prueba;


public interface PruebaRepository extends JpaRepository<Prueba, Integer> {

    @Query("""
        SELECT CASE WHEN COUNT(p) = 0 THEN true ELSE false END
        FROM Prueba p
        WHERE p.vehiculo.id = :vehiculoId AND p.fecha_hora_inicio <= CURRENT_TIMESTAMP AND p.fecha_hora_fin IS NULL
    """)
    boolean existsVehiculoDisponible(@Param("vehiculoId") Integer vehiculoId);

    @Query("""
            SELECT p
            FROM Prueba p
            WHERE p.fecha_hora_fin IS NULL
    """)
        List<Prueba> findPruebasEnCurso();

    @Query("SELECT p FROM Prueba p WHERE p.id = :id")
    Prueba findByIdPrueba(@Param("id") Long id);

    @Query("""
        SELECT CASE WHEN COUNT(p) = 0 THEN true ELSE false END
        FROM Prueba p
        WHERE p.empleado.legajo = :empleadoLegajo AND p.fecha_hora_inicio <= CURRENT_TIMESTAMP AND p.fecha_hora_fin IS NULL
    """)
    boolean existsEmpleadoDisponible(@Param("empleadoLegajo")Integer empleadoLegajo);

    @Query("""
        SELECT CASE WHEN COUNT(p) = 0 THEN true ELSE false END
        FROM Prueba p
        WHERE p.interesado.id = :interesadoId AND p.fecha_hora_inicio <= CURRENT_TIMESTAMP AND p.fecha_hora_fin IS NULL
    """)
    boolean existsInteresadoDisponible(@Param("interesadoId")Integer interesadoId);

}

