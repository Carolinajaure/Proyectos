package com.example.tpi_Back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpiBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
