package backend.controllers;

import backend.Entities.Vehiculo;
import backend.Services.NotificacionesService;
import backend.Services.PosicionesService;
import backend.Services.ServicioExterno;
import backend.Services.VehiculoService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionesController {
    private NotificacionesService notificacionesService;
    private ServicioExterno servicioExterno;
    private PosicionesService posicionesService;
    private VehiculoService vehiculoService;

    @Autowired
    public NotificacionesController(NotificacionesService service , PosicionesService posicionesService, ServicioExterno servicioExterno, VehiculoService vehiculoService) {
        this.notificacionesService = service;
        this.servicioExterno = servicioExterno;
        this.posicionesService = posicionesService;
        this.vehiculoService = vehiculoService;
    }

    @GetMapping("/obtenerDatosExternos")
    public Mono<String> getDatosService() {
        return servicioExterno.obtenerDatosExternos("https://labsys.frc.utn.edu.ar/apps-disponibilizadas/backend/api/v1/configuracion/");
    }

    @PostMapping("/registrarPosicion")
    public Mono<ResponseEntity<String>> registrarPosicion(
            @RequestParam Integer vehiculoId,
            @RequestParam Double latitudV,
            @RequestParam Double longitudV) {

        System.out.println("Entrando a registrarPosicion con vehiculoId: " + vehiculoId + ", latitudV: " + latitudV + ", longitudV: " + longitudV);

        return servicioExterno.obtenerDatosExternos("https://labsys.frc.utn.edu.ar/apps-disponibilizadas/backend/api/v1/configuracion/")
                .flatMap(datosJson -> {
                    try {
                        ObjectMapper objectMapper = new ObjectMapper();
                        JsonNode root = objectMapper.readTree(datosJson);

                        // Extraer los valores necesarios del JSON
                        JsonNode coordenadasAgencia = root.path("coordenadasAgencia");
                        double latitudAgencia = coordenadasAgencia.path("lat").asDouble();
                        double longitudAgencia = coordenadasAgencia.path("lon").asDouble();
                        double radio = root.path("radioAdmitidoKm").asDouble();

                        JsonNode zonaRestringida = root.path("zonasRestringidas").get(0);
                        double latitudNorteZ = zonaRestringida.path("noroeste").path("lat").asDouble();
                        double longitudNorteZ = zonaRestringida.path("noroeste").path("lon").asDouble();
                        double latitudSurZ = zonaRestringida.path("sureste").path("lat").asDouble();
                        double longitudSurZ = zonaRestringida.path("sureste").path("lon").asDouble();

                        // Buscar vehículo
                        Vehiculo vehiculoEncontrado = vehiculoService.buscarVehiculoById(vehiculoId);
                        if (vehiculoEncontrado != null) {
                            System.out.println("Vehículo encontrado: " + vehiculoEncontrado);

                            // Guardar posiciones
                            posicionesService.guardarPosicion(vehiculoEncontrado, latitudV, longitudV);
                        }

                        // Llamada al servicio de notificaciones
                        String notificacion = notificacionesService.crearNotificacionSiVehiculoEnZonaPeligrosa(
                                vehiculoId,
                                latitudV,
                                longitudV,
                                longitudNorteZ,
                                latitudNorteZ,
                                longitudSurZ,
                                latitudSurZ,
                                latitudAgencia,
                                longitudAgencia,
                                radio
                        );

                        return Mono.just(ResponseEntity.ok(notificacion));
                    } catch (Exception e) {
                        System.out.println("Error al procesar datos JSON: " + e.getMessage());
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al procesar datos JSON"));
                    }
                })
                .onErrorResume(e -> {
                    System.out.println("Error al obtener datos desde el servicio externo: " + e.getMessage());
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al obtener datos desde la API"));
                });
    }

    @PostMapping("/notificar/promocion")
        public ResponseEntity<String> createNotificacionPromocion(
                @RequestParam Integer telefonoDestinatario) {
            log.info("Entrando a createNotificacionPromocion con telefonoDestinatario: {}", telefonoDestinatario);
            String notificacion = notificacionesService.notificarPromocion(telefonoDestinatario);
            return ResponseEntity.ok(notificacion);
        }
}
