package backend.controllers;

import backend.Services.ReportesService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDateTime;

@Slf4j
@RestController
@RequestMapping("/api/notificaciones")
public class ReportesController {

    private ReportesService reportesService;

    @Autowired
    public ReportesController(ReportesService service) {
        this.reportesService = service;
    }

    @GetMapping("/generar-reporte-incidentes")
    public String generarReporteIncidentes() {
        return reportesService.generarReporteIncidentes();
    }

    @GetMapping("/generar-reporte-empleado")
    public String generarReporteEmpleado(@RequestParam Long legajo) {
        return reportesService.generarReporteEmpleado(legajo);
    }

    @GetMapping("/generar-reporte-km-vehiculo")
    public String generarReporteKmVehiculo(@RequestParam Integer idVehiculo, @RequestParam LocalDateTime fechaDesde, @RequestParam LocalDateTime fechaHasta) {
        return reportesService.generarReporteKmVehiculo(idVehiculo, fechaDesde, fechaHasta);
    }

    @GetMapping("/generar-reporte-pruebas-de-vehiculo")
    public String generarReportePruebasDeVehiculo(@RequestParam Integer idVehiculo) {
        return reportesService.generarReportePruebasDeVehiculo(idVehiculo);
    }
}
