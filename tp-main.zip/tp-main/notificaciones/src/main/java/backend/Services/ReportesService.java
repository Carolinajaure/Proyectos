package backend.Services;

import backend.CrudRepository.NotificacionesRepository;
import backend.CrudRepository.PosicionRepositorio;
import backend.CrudRepository.PruebaRepository;
import backend.Entities.Prueba;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReportesService {
    private NotificacionesRepository repositorioNotificaciones;
    private PosicionRepositorio repositorioPosiciones;
    private NotificacionesService notificacionesService;
    private PruebaRepository repositorioPruebas;

    @Autowired
    public ReportesService(NotificacionesRepository repositorioNotificaciones, PosicionRepositorio repositorioPosiciones, NotificacionesService notificacionesService , PruebaRepository repositorioPruebas) {
        this.repositorioNotificaciones = repositorioNotificaciones;
        this.repositorioPosiciones = repositorioPosiciones;
        this.notificacionesService = notificacionesService;
        this.repositorioPruebas = repositorioPruebas;
    }

    public String generarReporteIncidentes() {
        List<Prueba> pruebas = repositorioNotificaciones.findPruebasLimiteExcedido();

        System.out.println("REPORTE INCIDENTES (Limites excedidos)");
        for (Prueba prueba : pruebas) {
            System.out.println("--REPORTE GENERADO--");
            return "REPORTE INCIDENTES (Limites excedidos)\n" + "Prueba con límite excedido: " + prueba.toString() + " empleado: " + prueba.getEmpleado().getLegajo() + " vehiculo patente: "
                    + prueba.getVehiculo().getPatente() + " interesado id: " + prueba.getInteresado().getId();
        }
        return ("Fin del reporte");
    }

    public String generarReporteEmpleado(Long legajo) {
        List<Prueba> pruebas = repositorioNotificaciones.findPruebasLimiteExcedidoPorLegajo(legajo);
        System.out.println("REPORTE INCIDENTES PARA UN EMPLEADO");
        for (Prueba prueba : pruebas) {
            System.out.println("--REPORTE GENERADO--");
            return "REPORTE INCIDENTES (Limites excedidos) para el empleado con legajo: " + legajo + "\n" + "Prueba con límite excedido: " + prueba.toString()+ " vehiculo patente: "
                    + prueba.getVehiculo().getPatente() + " interesado id: " + prueba.getInteresado().getId();
        }
        return ("Fin de Reporte");
    }

    public String generarReporteKmVehiculo(Integer idVehiculo, LocalDateTime fechaDesde, LocalDateTime fechaHasta){

        List<Object[]> posiciones = repositorioPosiciones.posicionesVehiculo(idVehiculo, fechaDesde, fechaHasta);
        double distanciaTotal = 0;
        System.out.println("REPORTE PRUEBAS DE KM VEHICULO");
        for (int i = 0; i < posiciones.size() - 1; i++) {
            Object[] posicionActual = posiciones.get(i);
            Object[] posicionSiguiente = posiciones.get(i + 1);
            Double latitudActual = (Double) posicionActual[0];
            Double longitudActual = (Double) posicionActual[1];
            Double latitudSiguiente = (Double) posicionSiguiente[0];
            Double longitudSiguiente = (Double) posicionSiguiente[1];
            double distancia = notificacionesService.calcularDistancia(latitudActual, longitudActual, latitudSiguiente, longitudSiguiente);
            distanciaTotal += distancia;
        }
        System.out.println("--REPORTE GENERADO--");
        return "REPORTE KM VEHICULO (cant km recorridos) para el vehiculo con id: " + idVehiculo + "\n" + "Distancia total recorrida: " + distanciaTotal;
    }

    public String generarReportePruebasDeVehiculo(Integer idVehiculo){
        List<Prueba> pruebas = repositorioPruebas.buscarPruebasDeVehiculo(idVehiculo);
        System.out.println("REPORTE PRUEBAS DE VEHICULO");
        for (Prueba prueba : pruebas) {
            System.out.println("--REPORTE GENERADO--");
            return "REPORTE PRUEBAS DE VEHICULO\n para el vehiculo con id: " + idVehiculo +"\n" + "Prueba: " + prueba.toString() + " empleado: " + prueba.getEmpleado().getLegajo() + " interesado id: " + prueba.getInteresado().getId();
        }
        return ("Fin de Reporte");
        }
}

