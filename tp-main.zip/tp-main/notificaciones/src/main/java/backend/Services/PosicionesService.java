package backend.Services;

import backend.CrudRepository.PosicionRepositorio;
import backend.CrudRepository.PruebaRepository;
import backend.Entities.Posicion;
import backend.Entities.Vehiculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class PosicionesService {

    private PosicionRepositorio repositorioPosiciones;
    private PruebaRepository pruebaRepository;

    @Autowired
    public PosicionesService(PosicionRepositorio repositorioPosiciones, PruebaRepository pruebaRepository) {
        this.repositorioPosiciones = repositorioPosiciones;
        this.pruebaRepository = pruebaRepository;
    }

    public String guardarPosicion(Vehiculo vehiculo, Double latitud, Double longitud){
        if  (pruebaRepository.pruebaVehiculoEnCurso(vehiculo.getId()).isEmpty()){
            return "No se encontro el vehiculo en una prueba";}
        Posicion nuevaPosicion = new Posicion();
        nuevaPosicion.setFechaHora(LocalDateTime.now());
        nuevaPosicion.setLatitud(latitud);
        nuevaPosicion.setLongitud(longitud);
        nuevaPosicion.setVehiculo(vehiculo);
        repositorioPosiciones.save(nuevaPosicion);
        System.out.println("Se guardo la posicion");
        return ("Se guardó el vehiculo");
        }
}


