package backend.Services;

import backend.CrudRepository.*;
import backend.Entities.Interesado;
import backend.Entities.Notificacion;
import backend.Entities.Prueba;
import backend.Entities.Vehiculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class NotificacionesService {
    private NotificacionesRepository repositorioNotificaciones;
    private VehiculoRepository repositorioVehiculo;
    private PruebaRepository repositorioPrueba;
    private InteresadoRepository repositorioInteresado;

    @Autowired
    public NotificacionesService(NotificacionesRepository repositorioNotificaciones,
                                 VehiculoRepository repositorioVehiculo, PruebaRepository repositorioPrueba, InteresadoRepository repositorioInteresado) {
        this.repositorioNotificaciones = repositorioNotificaciones;
        this.repositorioVehiculo = repositorioVehiculo;
        this.repositorioPrueba = repositorioPrueba;
        this.repositorioInteresado = repositorioInteresado;
    }

    public double calcularDistancia(Double latitudV, Double longitudV, Double latitudAgencia, Double longitudAgencia) {
        double latDiff = latitudV - latitudAgencia;
        double lonDiff = longitudV - longitudAgencia;
        return Math.sqrt(latDiff * latDiff + lonDiff * lonDiff);
    }

    private boolean esVehiculoParaNotificar(Double latitudV, Double longitudV, Double longitudNorteZ, Double latitudNorteZ, Double longitudSurZ, Double latitudSurZ, Double latitudAgencia, Double longitudAgencia, Double radio) {
        if (calcularDistancia(latitudV, longitudV, latitudAgencia, longitudAgencia) > radio) {
            return true;
        }
        else if (latitudV >= latitudSurZ && latitudV <= latitudNorteZ && longitudV <= longitudSurZ && longitudV >= longitudNorteZ) {
            return true;
        }
        return false;
    }

    @Transactional
    public String crearNotificacionSiVehiculoEnZonaPeligrosa(Integer vehiculoId,Double latitudV, Double longitudV, Double longitudNorteZ ,
                                                             Double latitudNorteZ, Double longitudSurZ, Double latitudSurZ,
                                                            Double latitudAgencia,Double longitudAgencia, Double radio) {

        Optional<Vehiculo> vehiculoOpt = repositorioVehiculo.findById(vehiculoId);
        if (!vehiculoOpt.isPresent()) {
            return "No se encontró el vehículo";
        }

        if (esVehiculoParaNotificar(latitudV, longitudV, longitudNorteZ, latitudNorteZ, longitudSurZ, latitudSurZ, latitudAgencia, longitudAgencia, radio)) {
            Optional<Prueba> pruebaOpt = repositorioPrueba.pruebaVehiculoEnCurso(vehiculoId);
            if (pruebaOpt.isPresent()) {
                Prueba prueba = pruebaOpt.get();
                Notificacion nuevaNotificacion = new Notificacion();
                nuevaNotificacion.setCuerpo("Vehiculo no cumple las reglas de posicion");
                nuevaNotificacion.setPrueba(prueba);
                nuevaNotificacion.setFechaHoraEnvio(LocalDateTime.now());
                nuevaNotificacion.setTelefonoDestinatario(prueba.getEmpleado().getTelefono());

                repositorioNotificaciones.save(nuevaNotificacion);

                //Actualizar interesado como restringido
                Interesado interesado = prueba.getInteresado();
                interesado.setRestringido(true);
                repositorioInteresado.save(interesado);

                return "Notificación creada";
            } else {
                return "No hay una prueba en curso para el vehículo";
            }
        } else {
            return "No hay nada que notificar";
        }
    }

    @Transactional
    public String notificarPromocion(Integer telefonoDestinatario){
        Notificacion nuevaNotificacion = new Notificacion();
        nuevaNotificacion.setCuerpo("Promocion de la semana");
        nuevaNotificacion.setFechaHoraEnvio(LocalDateTime.now());
        nuevaNotificacion.setTelefonoDestinatario(telefonoDestinatario);
        repositorioNotificaciones.save(nuevaNotificacion);
        return "Notificación creada";
    }
}
