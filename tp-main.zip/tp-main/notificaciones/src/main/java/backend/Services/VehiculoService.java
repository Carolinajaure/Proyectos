package backend.Services;

import backend.CrudRepository.VehiculoRepository;
import backend.Entities.Vehiculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class VehiculoService {

    private VehiculoRepository vehiculoRepository;

    @Autowired
    public VehiculoService(VehiculoRepository vehiculoRepository) {
        this.vehiculoRepository = vehiculoRepository;
    }

    public Vehiculo buscarVehiculoById(Integer vehiculoId){
        if(vehiculoRepository.findById(vehiculoId).isPresent()){
            return vehiculoRepository.findById(vehiculoId).get();
        }
        return null;
    }
}
