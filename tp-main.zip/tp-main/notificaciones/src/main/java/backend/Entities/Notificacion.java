package backend.Entities;

import jakarta.persistence.*;
import java.time.LocalDateTime;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Table(name = "Notificaciones")
public class Notificacion {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private Long id;

    @Column(name = "CUERPO", nullable = false)
    private String cuerpo;

    @Column(name = "FECHA_HORA_ENVIO", nullable = false)
    private LocalDateTime fechaHoraEnvio;

    @ManyToOne (cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_PRUEBA")
    private Prueba prueba;

    @Column(name = "TELEFONO_DESTINATARIO" , nullable = false)
    private Integer telefonoDestinatario;

    public void setId(Long id) {
        this.id = id;
    }

    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }

    public void setFechaHoraEnvio(LocalDateTime fechaHoraEnvio) {
        this.fechaHoraEnvio = fechaHoraEnvio;
    }

    public void setPrueba(Prueba prueba) {
        this.prueba = prueba;
    }

    public void setTelefonoDestinatario(Integer telefonoEmpleado) {
        this.telefonoDestinatario = telefonoEmpleado;
    }

    public Long getId() {
        return id;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public LocalDateTime getFechaHoraEnvio() {
        return fechaHoraEnvio;
    }

    public Prueba getPrueba() {
        return prueba;
    }

    public Integer getTelefonoDestinatario() {
        return telefonoDestinatario;
    }

    @Override
    public String toString() {
        return "Notificacion{" +
                "id=" + id +
                ", cuerpo='" + cuerpo + '\'' +
                ", fechaHoraEnvio=" + fechaHoraEnvio +
                ", telefonoDestinatario='" + telefonoDestinatario + '\'' +
                '}';
    }
}



