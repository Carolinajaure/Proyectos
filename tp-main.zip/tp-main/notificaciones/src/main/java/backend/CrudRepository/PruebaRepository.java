package backend.CrudRepository;

import backend.Entities.Prueba;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface PruebaRepository extends JpaRepository<Prueba, Long>  {
    @Query("""
  SELECT p
  FROM Prueba p
  WHERE (CURRENT_TIMESTAMP > p.fecha_hora_inicio AND p.fecha_hora_fin IS NULL AND p.vehiculo.id = :id_vehiculo)
       
       
""")
    Optional<Prueba> pruebaVehiculoEnCurso(@Param("id_vehiculo") Integer id_vehiculo);

    @Query("SELECT p FROM Prueba p WHERE p.vehiculo.id = :id_vehiculo")
    List<Prueba> buscarPruebasDeVehiculo(@Param("id_vehiculo") Integer id_vehiculo);
}
