package backend.CrudRepository;

import backend.Entities.Notificacion;
import backend.Entities.Prueba;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface NotificacionesRepository extends JpaRepository<Notificacion, Long> {
    @Query("SELECT n.prueba FROM Notificacion n WHERE n.prueba IS NOT NULL")
    List<Prueba> findPruebasLimiteExcedido();

    @Query("SELECT n.prueba FROM Notificacion n WHERE n.prueba IS NOT NULL AND n.prueba.empleado.legajo = :legajo")
    List<Prueba> findPruebasLimiteExcedidoPorLegajo(@Param("legajo") Long legajo);
}
