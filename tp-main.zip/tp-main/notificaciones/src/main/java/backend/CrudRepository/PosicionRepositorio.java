package backend.CrudRepository;

import backend.Entities.Posicion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.List;

public interface PosicionRepositorio extends JpaRepository<Posicion, Long> {
    @Query("""
        SELECT p.latitud, p.longitud
        FROM Posicion p
        WHERE p.vehiculo.id = :id_vehiculo
        AND p.fechaHora BETWEEN :fecha_hora_desde AND :fecha_hora_hasta
    """)
    List<Object[]> posicionesVehiculo(
        @Param("id_vehiculo") Integer idVehiculo,
        @Param("fecha_hora_desde") LocalDateTime fechaHoraDesde,
        @Param("fecha_hora_hasta") LocalDateTime fechaHoraHasta
    );
}
