package backend.CrudRepository;

import backend.Entities.Interesado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InteresadoRepository extends JpaRepository<Interesado, Integer> {
    // Save
}
