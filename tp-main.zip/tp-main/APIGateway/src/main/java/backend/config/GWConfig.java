package backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.cloud.gateway.route.RouteLocator;

@Configuration
public class GWConfig {
    //este archivo redirige las solicitudes entrantes a diferentes microservicios
    @Bean
    public RouteLocator configurarRutas(RouteLocatorBuilder builder) {

        return builder.routes()
                // Ruteo al microservicio pruebas, redirige cualquier solicitud
                // que empiece con api/pruebas/al microservicio de pruebas
                .route(p -> p.path("/api/pruebas/**").uri("http://localhost:8081"))
                // Ruteo al microservicio notificaciones, redirige cualquier solicitud
                //que empiece con api/notificaciones/al microservicio de notificaciones
                .route(p -> p.path("/api/notificaciones/**").uri("http://localhost:8082"))
                .build();
    }
}