const request = require("supertest");
const app = require("../index");
const torneoAlta = {
  Nombre: "Torneo " + (() => (Math.random() + 1).toString(36).substring(2))(), 
  Tipo: "Eliminatorio", 
  Ubicacion: "Ciudad A", 
  IdDeporte: Math.floor(Math.random() * 10) + 1, 
  MaximoEquipos: Math.floor(Math.random() * 20) + 1, 
  FechaInicio: new Date(new Date().setDate(new Date().getDate() + Math.floor(Math.random() * 30))).toISOString().split('T')[0], // Fecha de inicio aleatoria en los próximos 30 días
  FechaFin: new Date(new Date().setDate(new Date().getDate() + 30 + Math.floor(Math.random() * 30))).toISOString(), // Fecha de fin aleatoria después de la fecha de inicio
  Activo: true, 
};
const torneoModificacion = {
  IdArticulo: 1,
  Nombre: "Torneo " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  Tipo: "Eliminatorio", 
  Ubicacion: "Ciudad A", 
  IdDeporte: Math.floor(Math.random() * 10) + 1, 
  MaximoEquipos: Math.floor(Math.random() * 20) + 1, 
  FechaInicio: new Date(new Date().setDate(new Date().getDate() + Math.floor(Math.random() * 30))).toISOString(), // Fecha de inicio aleatoria en los próximos 30 días
  FechaFin: new Date(new Date().setDate(new Date().getDate() + 30 + Math.floor(Math.random() * 30))).toISOString(), // Fecha de fin aleatoria después de la fecha de inicio
  Activo: true,
};

// test route/torneos GET
describe("GET /api/torneos", () => {
  it("Deberia devolver todos los torneos paginados", async () => {
    const res = await request(app).get("/api/torneos?Pagina=1");
    expect(res.statusCode).toEqual(200);

    expect(res.body).toEqual(
      expect.objectContaining({
        Items: expect.arrayContaining([
          expect.objectContaining({
            IdTorneo: expect.any(Number),
            Nombre: expect.any(String),
            Tipo: expect.any(String),
            Ubicacion: expect.any(String),
            IdDeporte: expect.any(Number),
            MaximoEquipos: expect.any(Number),
            FechaInicio: expect.any(String),
            FechaFin: expect.any(String),
            Activo: expect.any(Boolean),
          }),
        ]),
        RegistrosTotal: expect.any(Number),
      })
    );
  });
});

// test route/torneos GET
describe("GET /api/torneos con filtros", () => {
  it("Deberia devolver los torneos según filtro ", async () => {
    const res = await request(app).get("/api/torneos?Nombre=Local&Activo=true&Pagina=1");
    expect(res.statusCode).toEqual(200);

    expect(verificarPropiedades(res.body.Items)).toEqual(true);
  
    function verificarPropiedades(array) {
      for (let i = 0; i < array.length; i++) {
        if (!array[i].Nombre.includes("Local") || !array[i].Activo) {
          return false;
        }
      }
      return true;
    }
  });
});


// test route/torneos/:id GET
describe("GET /api/torneos/:id", () => {
  it("Deberia devolver el torneo con el id 1", async () => {
    const res = await request(app).get("/api/torneos/1");
    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.objectContaining({
        IdTorneo: expect.any(Number),
        Nombre: expect.any(String),
        Tipo: expect.any(String),
        Ubicacion: expect.any(String),
        IdDeporte: expect.any(Number),
        MaximoEquipos: expect.any(Number),
        FechaInicio: expect.any(String),
        FechaFin: expect.any(String),
        Activo: expect.any(Boolean),
      })
    );
  });
});

// test route/torneos POST
describe("POST /api/torneos", () => {
  it("Deberia devolver el torneo que acabo de crear", async () => {
    const res = await request(app).post("/api/torneos").send(torneoAlta);
    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.objectContaining({
        IdTorneo: expect.any(Number),
        Nombre: expect.any(String),
        Tipo: expect.any(String),
        Ubicacion: expect.any(String),
        IdDeporte: expect.any(Number),
        MaximoEquipos: expect.any(Number),
        FechaInicio: expect.any(String),
        FechaFin: expect.any(String),
        Activo: expect.any(Boolean),
      })
    );
  });
});

// test route/torneos/:id PUT
describe("PUT /api/torneos/:id", () => {
  it("Deberia devolver el torneo con el id 1 modificado", async () => {
    const res = await request(app)
      .put("/api/torneos/1")
      .send(torneoModificacion);
    expect(res.statusCode).toEqual(204);
  });
});

// test route/torneos/:id DELETE
describe("DELETE /api/torneos/:id", () => {
  it("Debería devolver el torneo con el id 1 borrado", async () => {
    const res = await request(app).delete("/api/torneos/1");
    expect(res.statusCode).toEqual(200);

  
  });
});