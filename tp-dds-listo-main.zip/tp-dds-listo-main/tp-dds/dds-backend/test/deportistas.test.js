const request = require("supertest");
const app = require("../index");
const deportistaAlta = {
  Nombre: "Deportista " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  Apellido: "Apellido " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  NroDocumento: Math.floor(Math.random() * 100000),
  IdDeporte: 1,
  FechaNacimiento: new Date().toISOString(),
  ClubAsociado: "Club " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  Activo: true,
};
const deportistaModificacion = {
  Nombre: "Deportista " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  Apellido: "Apellido " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  NroDocumento: Math.floor(Math.random() * 100000),
  IdDeporte: 2,
  FechaNacimiento: new Date().toISOString(),
  ClubAsociado: "Club " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  Activo: true,
  
};

// test route/deportistas GET
describe("GET /api/deportistas", () => {
  it("Deberia devolver todos los deportistas paginados", async () => {
    const res = await request(app).get("/api/deportistas?Pagina=1");
    expect(res.statusCode).toEqual(200);

    expect(res.body).toEqual(
      expect.objectContaining({
        Items: expect.arrayContaining([
          expect.objectContaining({
            IdDeportista: expect.any(Number),
            Nombre: expect.any(String),
            Apellido: expect.any(String),
            NroDocumento: expect.any(Number),
            IdDeporte: expect.any(Number),
            FechaNacimiento: expect.any(String),
            ClubAsociado: expect.any(String),
            Activo: expect.any(Boolean)
            
          }),
        ]),
        RegistrosTotal: expect.any(Number),
      })
    );
  });
});

// test route/deportistas GET
describe("GET /api/deportistas con filtros", () => {
  it("Deberia devolver los deportistas según filtro ", async () => {
    const res = await request(app).get("/api/deportistas?Nombre=AIRE&Activo=true&Pagina=1");
    expect(res.statusCode).toEqual(200);

    expect(verificarPropiedades(res.body.Items) ).toEqual(true );
  
    function verificarPropiedades(array) {
      for (let i = 0; i < array.length; i++) {
        if ( !array[i].Nombre.includes("Juan") || !array[i].Activo ) {
          return false;
        }
      }
      return true;
    }
    
  });
});

// test route/deportistas/:id GET
describe("GET /api/deportistas/:id", () => {
  it("Deberia devolver el deportista con el id 1", async () => {
    const res = await request(app).get("/api/deportistas/1");
    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.objectContaining({
        IdDeportista: expect.any(Number),
        Nombre: expect.any(String),
        Apellido: expect.any(String),
        NroDocumento: expect.any(Number),
        IdDeporte: expect.any(Number),
        FechaNacimiento: expect.any(String),
        ClubAsociado: expect.any(String),
        Activo: expect.any(Boolean),
      })
    );
  });
});

// test route/deportistas POST
describe("POST /api/deportistas", () => {
  it("Deberia devolver el deportista que acabo de crear", async () => {
    const res = await request(app).post("/api/deportistas").send(deportistaAlta);
    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.objectContaining({
        IdDeportista: expect.any(Number),
        Nombre: expect.any(String),
        Apellido: expect.any(String),
        NroDocumento: expect.any(Number),
        IdDeporte: expect.any(Number),
        FechaNacimiento: expect.any(String),
        ClubAsociado: expect.any(String),
        Activo: expect.any(Boolean),
        
      })
    );
  });
});

// test route/deportistas/:id PUT
describe("PUT /api/deportistas/:id", () => {
  it("Deberia devolver el deportista con el id 1 modificado", async () => {
    const res = await request(app)
      .put("/api/deportistas/1")
      .send(deportistaModificacion);
    expect(res.statusCode).toEqual(204);
  });
});

// test route/deportistas/:id DELETE
describe("DELETE /api/deportistas/:id", () => {
  it("Debería devolver el deportista con el id 1 borrado", async () => {
    const res = await request(app).delete("/api/deportistas/1");
    expect(res.statusCode).toEqual(200);

    
  });
});
