const request = require("supertest");
const app = require("../index");
const { INTEGER, TEXT } = require("sequelize");
const { text } = require("stream/consumers");
const medicoAlta = {
  Nombre: "Medico " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  Apellido: "Apellido " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un apellido aleatorio
  Matricula: Math.floor(Math.random() * 100000), // Genera una matrícula aleatoria
  IdEspecialidad: Math.floor(Math.random() * 10) + 1, // Genera un ID de especialidad aleatorio entre 1 y 10
  Nacionalidad: "Argentina", // Ejemplo de nacionalidad fija
  FechaNacimiento: new Date(1980 + Math.floor(Math.random() * 40), Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1).toISOString().split('T')[0], // Genera una fecha de nacimiento aleatoria
  Activo: true, // Campo activo
  Telefono: Math.floor(Math.random() * 1000000000), // Genera un número de teléfono aleatorio
};
const medicoModificacion = {
  IdMedico: 1,
  Nombre: "Medico " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un nombre aleatorio
  Apellido: "Apellido " + (() => (Math.random() + 1).toString(36).substring(2))(), // Genera un apellido aleatorio
  Matricula: Math.floor(Math.random() * 100000), // Genera una matrícula aleatoria
  IdEspecialidad: Math.floor(Math.random() * 10) + 1, // Genera un ID de especialidad aleatorio entre 1 y 10
  Nacionalidad: "Argentina", // Ejemplo de nacionalidad fija
  FechaNacimiento: new Date(1980 + Math.floor(Math.random() * 40), Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1).toISOString().split('T')[0], // Genera una fecha de nacimiento aleatoria
  Activo: true, // Campo activo
  Telefono: Math.floor(Math.random() * 1000000000), // Genera un número de teléfono aleatorio
};

// test route/medicos GET
describe("GET /api/medicos", () => {
  it("Deberia devolver todos los medicos paginados", async () => {
    const res = await request(app).get("/api/medicos?Pagina=1");
    expect(res.statusCode).toEqual(200);

    expect(res.body).toEqual(
      expect.objectContaining({
        Items: expect.arrayContaining([
          expect.objectContaining({
            IdMedico: expect.any(INTEGER),
            Nombre: expect.any(TEXT),
            Matricula: expect.any(INTEGER),
            IdEspecialidad: expect.any(INTEGER),
            Nacionalidad: expect.any(TEXT),
            FechaNacimiento: expect.any(Date),
            Activo: expect.any(Boolean),
            Telefono: expect.any(INTEGER),
          }),
        ]),
        RegistrosTotal: expect.any(Number),
      })
    );
  });
});

// test route/medicos GET
describe("GET /api/medicos con filtros", () => {
  it("Deberia devolver los medicos según filtro ", async () => {
    const res = await request(app).get("/api/medicos?Nombre=AIRE&Activo=true&Pagina=1");
    expect(res.statusCode).toEqual(200);

    expect(verificarPropiedades(res.body.Items) ).toEqual(true );
  
    function verificarPropiedades(array) {
      for (let i = 0; i < array.length; i++) {
        if ( !array[i].Nombre.includes("Jose") || !array[i].Activo ) {
          return false;
        }
      }
      return true;
    }
    
  });
});

// test route/medicos/:id GET
describe("GET /api/medicos/:id", () => {
  it("Deberia devolver el medico con el id 1", async () => {
    const res = await request(app).get("/api/medicos/1");
    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.objectContaining({
            IdMedico: expect.any(INTEGER),
            Nombre: expect.any(TEXT),
            Matricula: expect.any(INTEGER),
            IdEspecialidad: expect.any(INTEGER),
            Nacionalidad: expect.any(TEXT),
            FechaNacimiento: expect.any(Date),
            Activo: expect.any(Boolean),
            Telefono: expect.any(INTEGER),
      })
    );
  });
});

// test route/medicos POST
describe("POST /api/medicos", () => {
  it("Deberia devolver el medico que acabo de crear", async () => {
    const res = await request(app).post("/api/medicos").send(medicoAlta);
    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.objectContaining({
            IdMedico: expect.any(INTEGER),
            Nombre: expect.any(TEXT),
            Matricula: expect.any(INTEGER),
            IdEspecialidad: expect.any(INTEGER),
            Nacionalidad: expect.any(TEXT),
            FechaNacimiento: expect.any(Date),
            Activo: expect.any(Boolean),
            Telefono: expect.any(INTEGER),
      })
    );
  });
});

// test route/medicos/:id PUT
describe("PUT /api/medicos/:id", () => {
  it("Deberia devolver el medico con el id 1 modificado", async () => {
    const res = await request(app)
      .put("/api/medicos/1")
      .send(medicoModificacion);
    expect(res.statusCode).toEqual(204);
  });
});

// test route/medicos/:id DELETE
describe("DELETE /api/medicos/:id", () => {
  it("Debería devolver el medicos con el id 1 borrado", async () => {
    const res = await request(app).delete("/api/medicos/1");
    expect(res.statusCode).toEqual(200);

  });
});