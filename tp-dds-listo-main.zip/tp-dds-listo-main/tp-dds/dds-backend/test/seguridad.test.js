const request = require("supertest");
const app = require("../index");

const usuarioAdmin = { usuario: "admin", clave: "123" };
const usuarioMiembro = { usuario: "carolina", clave: "456" };

describe("POST /api/login admin", function () {
  it("Devolvería error de autenticación porque tiene clave errónea", async function () {
    const res = await request(app)
      .post("/api/login")
      .send({ usuario: "admin", clave: "errónea" });

    expect(res.statusCode).toEqual(200);
    expect(res.body.message).toEqual("usuario or clave incorrecto");
  });

  it("Devolvería el token para usuario admin", async function () {
    const res = await request(app).post("/api/login").send(usuarioAdmin);

    expect(res.statusCode).toEqual(200);
    expect(res.body.accessToken).toEqual(expect.any(String));
  });
});

describe("GET /api/deportistasJWT", () => {
  it("Devolvería error porque falta token de autorización", async function () {
    const res = await request(app).get("/api/deportistasJWT");
    expect(res.statusCode).toEqual(401);
    expect(res.body.message).toEqual("Acceso denegado");
  });

  it("Devolvería error porque el token no es válido", async function () {
    const res = await request(app)
      .get("/api/deportistasJWT")
      .set("Authorization", "Bearer invalido");
    expect(res.statusCode).toEqual(403);
    expect(res.body.message).toEqual("token no es valido");
  });

  it("Devolvería todos los deportistas, solo autorizado para administradores", async function () {
    const res1 = await request(app).post("/api/login").send(usuarioAdmin);
    expect(res1.statusCode).toEqual(200);
    const token = res1.body.accessToken;

    const res = await request(app)
      .get("/api/deportistasJWT")
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          IdDeportista: expect.any(Number),
          Nombre: expect.any(String),
          Apellido: expect.any(String),
          NroDocumento: expect.any(Number),
          IdDeporte: expect.any(Number),
          FechaNacimiento: expect.any(String),
          Activo: expect.any(Boolean),
        }),
      ])
    );
  });

  it("Devolvería error de autorización porque solo están autorizados los administradores", async function () {
    const res1 = await request(app).post("/api/login").send(usuarioMiembro);
    expect(res1.statusCode).toEqual(200);
    const token = res1.body.accessToken;

    const res = await request(app)
      .get("/api/deportistasJWT")
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toEqual(403);
    expect(res.body.message).toEqual("usuario no autorizado!");
  });
});

describe("GET /api/medicosJWT", () => {
  it("Devolvería error porque falta token de autorización", async function () {
    const res = await request(app).get("/api/medicosJWT");
    expect(res.statusCode).toEqual(401);
    expect(res.body.message).toEqual("Acceso denegado");
  });

  it("Devolvería error porque el token no es válido", async function () {
    const res = await request(app)
      .get("/api/medicosJWT")
      .set("Authorization", "Bearer invalido");
    expect(res.statusCode).toEqual(403);
    expect(res.body.message).toEqual("token no es valido");
  });

  it("Devolvería todos los médicos, solo autorizado para administradores", async function () {
    const res1 = await request(app).post("/api/login").send(usuarioAdmin);
    expect(res1.statusCode).toEqual(200);
    const token = res1.body.accessToken;

    const res = await request(app)
      .get("/api/medicosJWT")
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          IdMedico: expect.any(Number),
          Nombre: expect.any(String),
          Apellido: expect.any(String),
          Matricula: expect.any(Number),
          IdEspecialidad: expect.any(Number),
          Nacionalidad: expect.any(String),
          FechaNacimiento: expect.any(String),
          Activo: expect.any(Boolean),
          Telefono: expect.any(Number),
        }),
      ])
    );
  });

  it("Devolvería error de autorización porque solo están autorizados los administradores", async function () {
    const res1 = await request(app).post("/api/login").send(usuarioMiembro);
    expect(res1.statusCode).toEqual(200);
    const token = res1.body.accessToken;

    const res = await request(app)
      .get("/api/medicosJWT")
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toEqual(403);
    expect(res.body.message).toEqual("usuario no autorizado!");
  });
});
describe("GET /api/torneosJWT", () => {

  it("Devolveria error, porque falta token de autorización", async function () {
    const res = await request(app).get("/api/torneosJWT");
    expect(res.statusCode).toEqual(401);
    expect(res.body.message).toEqual("Acceso denegado");
  });

  it("Devolveria error, porque el token no es válido", async function () {
    const res = await request(app).get("/api/torneosJWT")
    .set("Authorization", 'Bearer invalido');
    expect(res.statusCode).toEqual(403);
    expect(res.body.message).toEqual("token no es valido");
  });

  it("Devolvería todos los torneos, solo autorizado para administradores", async function () {
    const res1 = await request(app)
    .post("/api/login")
    .set("Content-type", "application/json")
    .send(usuarioAdmin);
    expect(res1.statusCode).toEqual(200);
    let token = res1.body.accessToken;

    const res = await request(app)
      .get("/api/torneosJWT")
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toEqual(200);
    expect(res.body).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          IdTorneo: expect.any(Number),
          Nombre: expect.any(String),
          Tipo: expect.any(String),
          Ubicacion: expect.any(String),
          IdDeporte: expect.any(Number),
          MaximoEquipos: expect.any(Number),
          FechaInicio: expect.any(Date),
          FechaFin: expect.any(Date),
          Activo: expect.any(Boolean),
        }),
      ])
    );
  });

  it("Devolvería error de autorizacion, porque solo están autorizados los administradores", async function () {
    const res1 = await request(app)
    .post("/api/login")
    .set("Content-type", "application/json")
    .send(usuarioMiembro);
    expect(res1.statusCode).toEqual(200);
    let token = res1.body.accessToken;

    const res = await request(app)
      .get("/api/torneosJWT")
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toEqual(403);
    expect(res.body.message).toEqual('usuario no autorizado!');
  });

});