const express =require("express") ;
const router = express.Router();

const db=require("../base-orm/sequelize-init.js") ;

router.get("/api/especialidades", async function (req, res, next) {
  let data = await db.especialidades.findAll({
    attributes: ["IdEspecialidad", "Nombre"],
  });
  res.json(data);
});

module.exports =router;