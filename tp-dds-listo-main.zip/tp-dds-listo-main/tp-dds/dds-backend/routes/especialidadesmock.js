const express=require("express") ;
const router = express.Router();

let arr_EspecialidadesMock = [
  {
    "IdEspecialidad": 1,
    "Nombre": "Dermatología"
  },
  {
    "IdEspecialidad": 2,
    "Nombre": "Cardiología"
  },
  {
    "IdEspecialidad": 3,
    "Nombre": "Neurología"
  },
  {
    "IdEspecialidad": 4,
    "Nombre": "Geriatría"
  },
  {
    "IdEspecialidad": 5,
    "Nombre": "Pediatría"
  },
  {
    "IdEspecialidad": 6,
    "Nombre": "Nefrología"
  },
  {
    "IdEspecialidad": 7,
    "Nombre": "Otorrinolaringología"
  },
  {
    "IdEspecialidad": 8,
    "Nombre": "Genética"
  },
  {
    "IdEspecialidad": 9,
    "Nombre": "Traumatología  y Ortopedia"
  },
  {
    "IdEspecialidad": 10,
    "Nombre": "Psiquiatría"
  }
];

router.get('/api/especialidadesmock', async function (req, res) {
  res.json(arr_EspecialidadesMock);
});

router.get('/api/especialidadesmock/:id', async function (req, res) {
    let especialidad = arr_EspecialidadesMock.find(
      (x) => x.IdEspecialidad == req.params.id
    );
    if (especialidad) res.json(especialidad);
    else res.status(404).json({ message: 'especialidad no encontrado' });
  });

router.post('/api/especialidadesmock/', (req, res) => {
    const { Nombre } = req.body;
    let especialidad = {
      Nombre,
      IdEspecialidad: Math.floor(Math.random()*100000),
    };
  
    
    arr_EspecialidadesMock.push(especialidad);
  
    res.status(201).json(especialidad);
  });
  

module.exports = router;