const express=require("express") ;
const router = express.Router();

let arr_DeportesMock = [
  {
    "IdDeporte": 1,
    "Nombre": "Tenis"
  },
  {
    "IdDeporte": 2,
    "Nombre": "Futbol"
  },
  {
    "IdDeporte": 3,
    "Nombre": "Basquet"
  },
  {
    "IdDeporte": 4,
    "Nombre": "Voley"
  },
  {
    "IdDeporte": 5,
    "Nombre": "Natacion"
  },
  {
    "IdDeporte": 6,
    "Nombre": "Atletismo"
  },
  {
    "IdDeporte": 7,
    "Nombre": "Ciclismo"
  },
  {
    "IdDeporte": 8,
    "Nombre": "Golf"
  },
  {
    "IdDeporte": 9,
    "Nombre": "Padel"
  },
  {
    "IdDeporte": 10,
    "Nombre": "Rugby"
  }
];

router.get('/api/deportesmock', async function (req, res) {
  res.json(arr_DeportesMock);
});

router.get('/api/deportesmock/:id', async function (req, res) {
    let deporte = arr_DeportesMock.find(
      (x) => x.IdDeporte == req.params.id
    );
    if (deporte) res.json(deporte);
    else res.status(404).json({ message: 'Deporte no encontrado' });
  });

router.post('/api/deportesmock/', (req, res) => {
    const { Nombre } = req.body;
    let deporte = {
      Nombre,
      IdDeporte: Math.floor(Math.random()*100000),
    };
  
    
    arr_DeportesMock.push(deporte);
  
    res.status(201).json(deporte);
  });
  

module.exports = router;
