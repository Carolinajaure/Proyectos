const express =require("express") ;
const router = express.Router();

const db=require("../base-orm/sequelize-init.js") ;

router.get("/api/deportes", async function (req, res, next) {
  let data = await db.deportes.findAll({
    attributes: ["IdDeporte", "Nombre"],
  });
  res.json(data);
});

module.exports =router;
