const express = require("express");
const cors = require("cors");
const deportesmockRouter = require("./routes/deportesmock");
const deportesRouter = require("./routes/deportes");
const deportistasRouter = require("./routes/deportistas");
const seguridadRouter = require("./routes/seguridad");
const especialidadesmockRouter=require("./routes/especialidadesmock") ;
const especialidadesRouter=require("./routes/especialidades") ;
const medicosRouter=require("./routes/medicos") ;
const torneosRouter=require("./routes/torneos") ;


// crear servidor
const app = express();
require("./base-orm/sqlite-init"); // crear base si no existe

// Configurar CORS
app.use(
  cors({
    origin: '*', 
    methods: ['GET', 'POST', 'PUT', 'DELETE'], // Métodos permitidos
    allowedHeaders: ['Content-Type', 'Authorization'] // Encabezados permitidos
  })
);

app.use(express.json()); // para poder leer json en el body

// controlar ruta
app.get("/", (req, res) => {
  res.send("Backend inicial TP-DDS!");
});

// Definir routers
app.use(deportesmockRouter);
app.use(deportesRouter);
app.use(deportistasRouter);
app.use(seguridadRouter);
app.use(especialidadesmockRouter);
app.use(especialidadesRouter);
app.use(medicosRouter);
app.use(torneosRouter);

app.use((req, res, next) => {
  res.status(404).send('No encontrada!');
});

// levantar servidor
if (!module.parent) { // si no es llamado por otro módulo, es decir, si es el módulo principal -> levantamos el servidor
  const port = process.env.PORT || 3000; // en producción se usa el puerto de la variable de entorno PORT
  app.locals.fechaInicio = new Date();
  app.listen(port, () => {
    console.log(`sitio escuchando en el puerto ${port}`);
  });
}

module.exports = app; 


  
