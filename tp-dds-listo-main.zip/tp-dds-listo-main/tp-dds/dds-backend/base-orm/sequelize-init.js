// configurar ORM sequelize
const { Sequelize, DataTypes } = require("sequelize");
//const sequelize = new Sequelize("sqlite:" + process.env.base );
const sequelize = new Sequelize("sqlite:" + "./.data/BD-TP.db");

// Definición del modelo de datos 'deportes'
const deportes = sequelize.define(
  "deportes",
  {
    IdDeporte: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    Nombre: {
      type: DataTypes.STRING(30),
      allowNull: false,
      validate: {
        notEmpty: {
          args: true,
          msg: "Nombre es requerido",
        },
        len: {
          args: [5, 30],
          msg: "Nombre debe tener entre 5 y 30 caracteres de longitud",
        },
      },
    },
  },
  {
    timestamps: false,
  }
);

// Definición del modelo de datos 'deportistas'
const deportistas = sequelize.define(
  "deportistas",
  {
    IdDeportista: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    Nombre: {
      type: DataTypes.STRING(60),
      allowNull: false,
      validate: {
        notEmpty: {
          args: true,
          msg: "Nombre es requerido",
        },
        len: {
          args: [3, 20],
          msg: "Nombre debe tener entre 3 y 20 caracteres de longitud",
        },
      },
    },
    Apellido: {
      type: DataTypes.STRING(60),
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Apellido es requerido",
        },
      },
    },
    NroDocumento: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Nro de Documento es requerido",
        },
        //unique: {
          //args: true,
          //msg: "Nro de Documento debe ser único",
        //},
        }
      },
    IdDeporte: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "IdDeporte es requerido",
        },
      },
    },
    FechaNacimiento: {
      type: DataTypes.DATE,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Fecha Nacimiento es requerido",
        },
      },
    },
    ClubAsociado: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    Activo: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Activo es requerido",
        },
      },
    },
  },
  {  
    timestamps: false,
  }
);

// Definición del modelo de datos 'especialidades'
const especialidades = sequelize.define(
  "especialidades",
  {
    IdEspecialidad: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    Nombre: {
      type: DataTypes.STRING(30),
      allowNull: false,
      validate: {
        notEmpty: {
          args: true,
          msg: "Nombre es requerido",
        },
        len: {
          args: [5, 30],
          msg: "Nombre debe tener entre 5 y 30 caracteres de longitud",
        },
      },
    },
  },
  {
    timestamps: false,
  }
);

// Definición del modelo de datos 'medicos'
const medicos = sequelize.define(
  "medicos",
  {
    IdMedico: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    Nombre: {
      type: DataTypes.STRING(60),
      allowNull: false,
      validate: {
        notEmpty: {
          args: true,
          msg: "Nombre es requerido",
        },
        len: {
          args: [5, 60],
          msg: "Nombre debe tener entre 5 y 60 caracteres de longitud",
        },
      },
    },
    Apellido: {
      type: DataTypes.STRING(60),
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Apellido es requerido",
        },
      },
    },
    Matricula: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Matricula es requerido",
        },
      },
    },
    IdEspecialidad: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "IdEspecialidad es requerido",
        },
      },
    },
    Nacionalidad: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Nacionalidad es requerido",
        },
      },
    },
    FechaNacimiento: {
      type: DataTypes.DATE,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Fecha de Nacimiento es requerido",
        },
      },
    },
    Activo: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Activo es requerido",
        },
      },
    },
    Telefono: {
      type: DataTypes.INTEGER,
      allowNull: true,
      validate: {
        isInt: {
          args: true,
          msg: "Telefono debe ser un número entero",
        },
      },
    },
  },
  {
    timestamps: false,
  }
);

// Definición del modelo de datos 'torneos'
const torneos = sequelize.define(
  "torneos",
  {
    IdTorneo: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    Nombre: {
      type: DataTypes.STRING(60),
      allowNull: false,
      validate: {
        notEmpty: {
          args: true,
          msg: "Nombre es requerido",
        },
        len: {
          args: [5, 60],
          msg: "Nombre debe tener entre 5 y 60 caracteres de longitud",
        },
      },
    },
    Tipo: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    Ubicacion: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    IdDeporte: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "IdDeporte es requerido",
        },
      },
    },
    MaximoEquipos: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    FechaInicio: {
      type: DataTypes.DATE,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "FechaInicio es requerido",
        },
      },
    },
    FechaFin: {
      type: DataTypes.DATE,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "FechaFin es requerido",
        },
      },
    },
    Activo: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "Activo es requerido",
        },
      },
    },
  },
  {
    timestamps: false,
  }
);

module.exports = {
  sequelize,
  deportes,
  deportistas,
  especialidades,
  medicos,
  torneos,
};
