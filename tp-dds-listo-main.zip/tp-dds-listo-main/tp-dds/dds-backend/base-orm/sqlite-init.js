// acceder a la base usando aa-sqlite
const db = require('aa-sqlite');


async function CrearBaseSiNoExiste() {
  // abrir base, si no existe el archivo/base lo crea
  await db.open("./.data/BD-TP.db");
  //await db.open(process.env.base

  let existe = false;
  let res = null;

  res = await db.get(
    "SELECT count(*) as contar FROM sqlite_schema WHERE type = 'table' and name= 'usuarios'",
    []
  );
  if (res.contar > 0) existe = true;
  if (!existe) {
    await db.run(
      "CREATE table usuarios( IdUsuario INTEGER PRIMARY KEY AUTOINCREMENT, Nombre text NOT NULL UNIQUE, Clave text NOT NULL, Rol text NOT NULL);"
    );
    console.log("tabla usuarios creada!");
    await db.run(
      "insert into usuarios values	(1,'admin','123','admin'),(2,'juan','123','member');"
    );
  }

  existe = false;
  res = await db.get(
    "SELECT count(*) as contar FROM sqlite_schema WHERE type = 'table' and name= 'deportes'",
    []
  );
  if (res.contar > 0) existe = true;
  if (!existe) {
    await db.run(
      "CREATE table deportes( IdDeporte INTEGER PRIMARY KEY AUTOINCREMENT, Nombre text NOT NULL UNIQUE);"
    );
    console.log("tabla deportes creada!");
    await db.run(
      "insert into deportes values	(1,'Tenis'),(2,'Futbol'),(3,'Basquet'),(4,'Voley'),(5,'Natacion'),(6,'Atletismo'),(7,'Ciclismo'),(8,'Golf'),(9,'Padel'),(10,'Rugby');"
    );
  }

  existe = false;
  let sql_dep =
    "SELECT count(*) as contar FROM sqlite_schema WHERE type = 'table' and name= 'deportistas'";
  res = await db.get(sql_dep, []);
  if (res.contar > 0) existe = true;
  if (!existe) {
    await db.run(
      `CREATE table deportistas( 
              IdDeportista INTEGER PRIMARY KEY AUTOINCREMENT
            , Nombre text NOT NULL 
            , Apellido text NOT NULL
            , NroDocumento integer NOT NULL 
            , IdDeporte integer not null
            , FechaNacimiento date NOT NULL
            , ClubAsociado text
            , Activo boolean,
            FOREIGN KEY (IdDeporte) REFERENCES deportes(IdDeporte)
            );`
    );
    console.log("tabla deportistas creada!");

    await db.run(
      `insert into deportistas values
      (1,'Juan', 'Pérez', 12345678, 1, '1990-05-15', 'Club Tenis', 1),
      (2,'Carlos', 'Gómez', 23456789, 2, '1988-03-22', 'Club Futbol', 1),
      (3,'Ana', 'Martínez', 34567890, 3, '1992-07-30', 'Club Basquet', 1),
      (4,'Laura', 'Fernández', 45678901, 4, '1991-01-11', 'Club Voley', 1),
      (5,'Marta', 'López', 56789012, 5, '1995-09-19', 'Club Natacion', 1),
      (6,'Pedro', 'García', 67890123, 6, '1987-12-05', 'Club Atletismo', 1),
      (7,'Jorge', 'Rodríguez', 78901234, 7, '1993-11-18', 'Club Ciclismo', 1),
      (8,'Luis', 'Hernández', 89012345, 8, '1990-06-21', 'Club Golf', 1),
      (9,'Sofía', 'Jiménez', 90123456, 9, '1996-04-07', 'Club Padel', 1),
      (10,'David', 'Ruiz', 12340987, 10, '1989-02-14', 'Club Rugby', 1),
      (11,'Andrea', 'Sánchez', 23459876, 1, '1994-10-23', 'Club Tenis', 1),
      (12,'María', 'Díaz', 34568765, 2, '1991-08-11', 'Club Futbol', 1),
      (13,'Miguel', 'Morales', 45677654, 3, '1986-05-17', 'Club Basquet', 1),
      (14,'Laura', 'Ortiz', 56786543, 4, '1993-07-28', 'Club Voley', 1),
      (15,'Patricia', 'Iglesias', 67895432, 5, '1988-11-03', 'Club Natacion', 1),
      (16,'Gabriel', 'Vargas', 78904321, 6, '1992-03-12', 'Club Atletismo', 1),
      (17,'Julio', 'Torres', 89013210, 7, '1990-09-09', 'Club Ciclismo', 1),
      (18,'Fernando', 'Castro', 90122109, 8, '1989-12-25', 'Club Golf', 1),
      (19,'Elena', 'Suárez', 12349876, 9, '1995-01-30', 'Club Padel', 1),
      (20,'Raúl', 'Giménez', 23458765, 10, '1987-04-08', 'Club Rugby', 1);`
    );
  }
  existe = false;
  let sql =
    "SELECT count(*) as contar FROM sqlite_schema WHERE type = 'table' and name= 'torneos'";
  res = await db.get(sql, []);
  if (res.contar > 0) existe = true;
  if (!existe) {
    await db.run(
      `CREATE table torneos( 
              IdTorneo INTEGER PRIMARY KEY AUTOINCREMENT
            , Nombre text NOT NULL 
            , Tipo TEXT
            , Ubicacion TEXT
            , IdDeporte integer NOT NULL
            , MaximoEquipos INTEGER
            , FechaInicio DATE NOT NULL
            , FechaFin DATE NOT NULL
            , Activo boolean,
            FOREIGN KEY (IdDeporte) REFERENCES deportes(IdDeporte)
            );`
    );
    console.log("tabla torneos creada!");

    await db.run(
      `insert into torneos (Nombre, Tipo, Ubicacion, IdDeporte, MaximoEquipos, FechaInicio, FechaFin, Activo) values
      ('Torneo Primavera', 'Eliminatorio', 'Ciudad A', 1, 16, '2024-03-01', '2024-03-10', 1),
      ('Torneo Verano', 'Round-Robin', 'Ciudad B', 2, 20, '2024-06-01', '2024-06-15', 1),
      ('Torneo Otoño', 'Eliminatorio', 'Ciudad C', 3, 12, '2024-09-01', '2024-09-10', 1),
      ('Torneo Invierno', 'Round-Robin', 'Ciudad D', 4, 18, '2024-12-01', '2024-12-15', 1),
      ('Torneo Nacional', 'Eliminatorio', 'Ciudad E', 5, 24, '2024-07-01', '2024-07-20', 1),
      ('Torneo Regional', 'Round-Robin', 'Ciudad F', 6, 10, '2024-04-01', '2024-04-07', 1),
      ('Torneo Juvenil', 'Eliminatorio', 'Ciudad G', 7, 14, '2024-05-01', '2024-05-08', 1),
      ('Torneo Master', 'Round-Robin', 'Ciudad H', 8, 22, '2024-08-01', '2024-08-14', 1),
      ('Torneo Femenino', 'Eliminatorio', 'Ciudad I', 9, 16, '2024-10-01', '2024-10-10', 1),
      ('Torneo Mixto', 'Round-Robin', 'Ciudad J', 10, 20, '2024-11-01', '2024-11-15', 1),
      ('Torneo Abierto', 'Eliminatorio', 'Ciudad K', 1, 18, '2024-01-01', '2024-01-10', 1),
      ('Torneo Estudiantil', 'Round-Robin', 'Ciudad L', 2, 12, '2024-02-01', '2024-02-07', 1),
      ('Torneo Internacional', 'Eliminatorio', 'Ciudad M', 3, 30, '2024-03-20', '2024-03-30', 1),
      ('Torneo Amistad', 'Round-Robin', 'Ciudad N', 4, 8, '2024-04-20', '2024-04-25', 1),
      ('Torneo Vecinal', 'Eliminatorio', 'Ciudad O', 5, 6, '2024-05-20', '2024-05-25', 1),
      ('Torneo Senior', 'Round-Robin', 'Ciudad P', 6, 16, '2024-06-20', '2024-06-30', 1),
      ('Torneo Junior', 'Eliminatorio', 'Ciudad Q', 7, 10, '2024-07-20', '2024-07-27', 1),
      ('Torneo Escolar', 'Round-Robin', 'Ciudad R', 8, 20, '2024-08-20', '2024-08-30', 1),
      ('Torneo Universitario', 'Eliminatorio', 'Ciudad S', 9, 24, '2024-09-20', '2024-09-30', 1),
      ('Torneo Local', 'Round-Robin', 'Ciudad T', 10, 14, '2024-10-20', '2024-10-27', 1)
      ;`
    );
  }
  
  existe = false;
    res = await db.get(
      "SELECT count(*) as contar FROM sqlite_schema WHERE type = 'table' and name= 'especialidades'",
      []
    );
    if (res.contar > 0) existe = true;
    if (!existe) {
      await db.run(
        "CREATE TABLE especialidades( IdEspecialidad INTEGER PRIMARY KEY AUTOINCREMENT, Nombre TEXT NOT NULL UNIQUE);"
      );
      console.log("Tabla especialidades creada!");
      await db.run(
        "INSERT INTO especialidades(IdEspecialidad, Nombre) VALUES (1, 'Dermatología'),(2, 'Cardiología'),(3, 'Neurología'),(4, 'Geriatría'),(5, 'Pediatría'),(6, 'Nefrología'),(7, 'Otorrinolaringología'),(8, 'Genética'),(9, 'Traumatología y Ortopedia'),(10, 'Psiquiatría');"
      );
    }

    existe = false;
    let sql_med =
      "SELECT count(*) as contar FROM sqlite_schema WHERE type = 'table' and name= 'medicos'";
    res = await db.get(sql_med, []);
    if (res.contar > 0) existe = true;
    if (!existe) {
      await db.run(
        `CREATE TABLE medicos( 
            IdMedico INTEGER PRIMARY KEY AUTOINCREMENT,
            Nombre TEXT NOT NULL,
            Apellido TEXT,
            Matricula INTEGER ,
            IdEspecialidad INTEGER,
            Nacionalidad TEXT,
            FechaNacimiento DATE,
            Activo BOOLEAN,
            Telefono INTEGER,
            FOREIGN KEY (IdEspecialidad) REFERENCES especialidades(IdEspecialidad)
          );`
      );
      console.log("Tabla medicos creada!");

      await db.run(
        `INSERT INTO medicos(IdMedico, Nombre, Apellido, Matricula, IdEspecialidad, Nacionalidad, FechaNacimiento, Activo, Telefono) VALUES
          (1, 'Juan', 'Pérez', 12345, 1, 'Argentina', '1980-01-01', 1, 1234567890),
          (2, 'María', 'González', 12346, 2, 'Chile', '1985-02-15', 1, 2345678901),
          (3, 'Carlos', 'Ramírez', 12347, 3, 'Uruguay', '1990-03-30', 1, 3456789012),
          (4, 'Ana', 'Fernández', 12348, 4, 'Perú', '1975-04-25', 1, 4567890123),
          (5, 'Luis', 'Martínez', 12349, 5, 'Brasil', '1988-05-10', 1, 5678901234),
          (6, 'Laura', 'Gómez', 12350, 6, 'Paraguay', '1979-06-05', 1, 6789012345),
          (7, 'Diego', 'López', 12351, 7, 'Bolivia', '1983-07-20', 1, 7890123456),
          (8, 'Lucía', 'Díaz', 12352, 8, 'Colombia', '1992-08-14', 1, 8901234567),
          (9, 'Santiago', 'Álvarez', 12353, 9, 'Ecuador', '1981-09-23', 1, 9012345678),
          (10, 'Sofía', 'Torres', 12354, 10, 'Venezuela', '1995-10-30', 1, 1230984567),
          (11, 'Mateo', 'Suárez', 12355, 1, 'Argentina', '1984-11-25', 1, 2341095678),
          (12, 'Valentina', 'Molina', 12356, 2, 'Chile', '1987-12-19', 1, 3452106789),
          (13, 'Martín', 'Rojas', 12357, 3, 'Uruguay', '1991-01-15', 1, 4563217890),
          (14, 'Camila', 'Castro', 12358, 4, 'Perú', '1978-02-17', 1, 5674328901),
          (15, 'Joaquín', 'Ortiz', 12359, 5, 'Brasil', '1986-03-12', 1, 6785439012),
          (16, 'Emilia', 'Silva', 12360, 6, 'Paraguay', '1982-04-18', 1, 7896540123),
          (17, 'Sebastián', 'Morales', 12361, 7, 'Bolivia', '1989-05-22', 1, 8907651234),
          (18, 'Mía', 'Cruz', 12362, 8, 'Colombia', '1993-06-27', 1, 9018762345),
          (19, 'Tomás', 'Reyes', 12363, 9, 'Ecuador', '1977-07-30', 1, 1239873456),
          (20, 'Isabella', 'Herrera', 12364, 10, 'Venezuela', '1994-08-29', 1, 2340984567);`
      );
    }

  // cerrar la base
  db.close();
}

CrearBaseSiNoExiste();

module.exports = CrearBaseSiNoExiste;
