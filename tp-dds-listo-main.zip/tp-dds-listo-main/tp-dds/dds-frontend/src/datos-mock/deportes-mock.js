const arrayDeporte = [
    { IdDeporte: 1, Nombre: "Tenis" },
    { IdDeporte: 2, Nombre: "Futbol" },
    { IdDeporte: 3, Nombre: "Basquet" },
    { IdDeporte: 4, Nombre: "Voley" },
    { IdDeporte: 5, Nombre: "Natacion" },
    { IdDeporte: 6, Nombre: "Atletismo" },
    { IdDeporte: 7, Nombre: "Ciclismo" },
    { IdDeporte: 8, Nombre: "Golf" },
    { IdDeporte: 9, Nombre: "Padel" },
    { IdDeporte: 10, Nombre: "Rugby" },
]
export default arrayDeporte;
