const arrayEspecialidad = [
    { IdEspecialidad: 1, Nombre: "Dermatología" },
    { IdEspecialidad: 2, Nombre: "Cardiología" },
    { IdEspecialidad: 3, Nombre: "Neurología" },
    { IdEspecialidad: 4, Nombre: "Geriatría" },
    { IdEspecialidad: 5, Nombre: "Pediatría" },
    { IdEspecialidad: 6, Nombre: "Nefrología" },
    { IdEspecialidad: 7, Nombre: "Otorrinolaringología" },
    { IdEspecialidad: 8, Nombre: "Genética" },
    { IdEspecialidad: 9, Nombre: "Traumatología y Ortopedia" },
    { IdEspecialidad: 10, Nombre: "Psiquiatría" },
]
export default arrayEspecialidad;