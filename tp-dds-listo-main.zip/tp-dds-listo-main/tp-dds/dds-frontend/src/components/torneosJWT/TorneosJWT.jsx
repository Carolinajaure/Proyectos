import React, { useState, useEffect } from "react";
import { torneosJWTService } from "../../services/torneosJWT.service.js";

function TorneosJWT() {
  const tituloPagina = "Torneos JWT (solo para admintradores)";
  const [torneos, setTorneos] = useState(null);

  // cargar al iniciar el componente, solo una vez
  useEffect(() => {
    BuscarTorneosJWT();
  }, []);

  async function BuscarTorneosJWT() {
     try {
      let data = await torneosJWTService.Buscar();
      setTorneos(data);
    } catch (error) {
      console.log("error al buscar datos en el servidor!")
    }
  }
  return (
        <>
        <div className="tituloPagina">{tituloPagina}</div>
        <table className="table table-bordered table-striped">
            <thead>
                <tr>
                    <th style={{ width: "20%" }}>IdTorneo</th>
                    <th style={{ width: "50%" }}>Nombre</th>
                    <th style={{ width: "30%" }}>Tipo</th>
                </tr>
            </thead>
            <tbody>
                {torneos &&
                    torneos.map((deporte) => (
                    <tr key={deporte.IdTorneo}>
                        <td>{deporte.IdTorneo}</td>
                        <td>{deporte.Nombre}</td>
                        <td>{deporte.Tipo}</td>
                    </tr>
                    ))}
            </tbody>
        </table>
    </>
);
}
TorneosJWT.NombreComponenteNoOfuscado = "TorneosJWT";
export { TorneosJWT };