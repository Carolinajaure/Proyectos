function Inicio() {
  return (
    <div className="mt-4 p-5 rounded" style={{ backgroundColor: "lightgray" }}>
      <h1>TP-DDS</h1>
      <p>Este Trabajo Practico de la materia Desarrollo de Software fue realizado por las alumnas:</p>
      <p>
       Jaureguialzo Carolina - 94278
      </p>
      <p>
        Odar Esmeralda - 95230
      </p>
      <p>
        Pedraza Antonella - 94868
      </p>
    </div>
  );
}
export  { Inicio} ;
