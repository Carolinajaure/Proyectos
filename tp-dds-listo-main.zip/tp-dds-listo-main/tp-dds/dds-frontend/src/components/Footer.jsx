
function Footer() {
  return (
    <footer className="text-center">
    <small>
      <span>Inscripciones a Torneos</span>
      <span className="m-4">-</span>
      <a href="tel:113"> <span className="fa fa-phone"></span> 0810-888-1234 </a>
    </small>
  </footer>

  );
}
export { Footer };
