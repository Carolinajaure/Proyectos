import React from "react";
import { useForm } from "react-hook-form";

export default function TorneosRegistro({
  AccionABMC,
  Deportes,
  Item,
  Grabar,
  Volver,
}) {
  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields, isValid, isSubmitted },
  } = useForm({ values: Item });
  const onSubmit = (data) => {
    Grabar(data);
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="container-fluid">

        <fieldset disabled={AccionABMC === "C"}>

          {/* campo nombre */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Nombre">
                Nombre<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
            <input
                type="text"
                {...register("Nombre", {
                  required: { value: true, message: "Nombre es requerido" },
                  minLength: {
                    value: 4,
                    message: "Nombre debe tener al menos 4 caracteres",
                  },
                  maxLength: {
                    value: 55,
                    message: "Nombre debe tener como máximo 55 caracteres",
                  },
                })}
                autoFocus
                className={
                  "form-control " + (errors?.Nombre ? "is-invalid" : "")
                }
              />
              {errors?.Nombre && touchedFields.Nombre && (
                <div className="invalid-feedback">
                  {errors?.Nombre?.message}
                </div>
              )}

            </div>
          </div>

          {/* Campo Tipo */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Tipo">
                Tipo de Torneo<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("Tipo", {
                  required: { value: true, message: "Tipo de Torneo es requerido" },
                  minLength: {
                    value: 5,
                    message: "Tipo de Torneo debe tener al menos 5 caracteres",
                  },
                  maxLength: {
                    value: 50,
                    message: "Tipo de Torneo debe tener como máximo 50 caracteres",
                  },
                })}
                className={"form-control " + (errors?.Tipo ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">{errors?.Tipo?.message}</div>
            </div>
          </div>

          {/* Campo Ubicacion */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Ubicacion">
                Ubicación<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("Ubicacion", {
                  required: { value: true, message: "Ubicación es requerida" },
                  minLength: {
                    value: 5,
                    message: "Ubicación debe tener al menos 5 caracteres",
                  },
                  maxLength: {
                    value: 50,
                    message: "Ubicación debe tener como máximo 50 caracteres",
                  },
                })}
                className={"form-control " + (errors?.Ubicacion ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">{errors?.Ubicacion?.message}</div>
            </div>
          </div>


          {/* campo idDeporte */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="IdDeporte">
                Deporte<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
            <select
              {...register("IdDeporte", {
                required: { value: true, message: "Deporte es requerido" },
              })}
              className={
                "form-control " +
                (errors?.IdDeporte ? "is-invalid" : "")
              }
            >
              <option value="" key={1}></option>
              {Deportes?.map((x) => (
                <option value={x.IdDeporte} key={x.IdDeporte}>
                  {x.Nombre}
                </option>
              ))}
            </select>
            <div className="invalid-feedback">
              {errors?.IdDeporte?.message}
            </div>

            </div>
          </div>

          {/* Campo MaximoEquipos */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="MaximoEquipos">
                Máximo Equipos<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="number"
                {...register("MaximoEquipos", {
                  required: { value: true, message: "Máximo Equipos es requerido" },
                  min: {
                    value: 1,
                    message: "Máximo Equipos debe ser mayor a 0",
                  },
                  max: {
                    value: 100,
                    message: "Máximo Equipos debe ser menor o igual a 100",
                  },
                })}
                className={"form-control " + (errors?.MaximoEquipos ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">{errors?.MaximoEquipos?.message}</div>
            </div>
          </div>

          {/* Campo FechaInicio */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="FechaInicio">
                Fecha Inicio<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="date"
                {...register("FechaInicio", {
                  required: { value: true, message: "Fecha Inicio es requerida" }
                })}
                className={"form-control " + (errors?.FechaInicio ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">
                {errors?.FechaInicio?.message}
              </div>
            </div>
          </div>

          {/* Campo FechaFin */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="FechaFin">
                Fecha Fin<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="date"
                {...register("FechaFin", {
                  required: { value: true, message: "Fecha Fin es requerida" },
                  validate: {
                    greaterThanStartDate: (value) => {
                      const startDate = new Date(Item.FechaInicio);
                      const endDate = new Date(value);
                      return endDate > startDate || "La fecha de fin debe ser mayor a la fecha de inicio";
                    }
                  }
                })}
                className={"form-control " + (errors?.FechaFin ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">
                {errors?.FechaFin?.message}
              </div>
            </div>
          </div>

          {/* campo Activo */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Activo">
                Activo<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <select
                {...register("Activo")}
                className="form-control"
                disabled
              >
                <option value={null}></option>
                <option value={false}>NO</option>
                <option value={true}>SI</option>
              </select>
            </div>
          </div>

        </fieldset>

        {/* Botones Grabar, Cancelar/Volver' */}
        <hr />
        <div className="row justify-content-center">
          <div className="col text-center botones">
            {AccionABMC !== "C" && (
              <button type="submit" className="btn btn-primary">
                <i className="fa fa-check"></i> Grabar
              </button>
            )}
            <button
              type="button"
              className="btn btn-warning"
              onClick={() => Volver()}
            >
              <i className="fa fa-undo"></i>
              {AccionABMC === "C" ? " Volver" : " Cancelar"}
            </button>
          </div>
        </div>

        {/* texto: Revisar los datos ingresados... */}
        {!isValid && isSubmitted && (
          <div className="row alert alert-danger mensajesAlert">
            <i className="fa fa-exclamation-sign"></i>
            Revisar los datos ingresados...
          </div>
        )}
      </div>
    </form>
  );
}