import React from "react";
import { useForm } from "react-hook-form";

export default function DeportistasRegistro({
  AccionABMC,
  Deportes ,
  Item,
  Grabar,
  Volver,
}) {
  // Ensure defaultValues is initialized with Item or an empty object
  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields, isValid, isSubmitted },
  } = useForm({ defaultValues: Item || {} }); // Use defaultValues with Item or empty object

  const onSubmit = (data) => {
    Grabar(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="container-fluid">
        <fieldset disabled={AccionABMC === "C"}>
          {/* campo nombre */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Nombre">
                Nombre<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("Nombre", {
                  required: { value: true, message: "Nombre es requerido" },
                  minLength: {
                    value: 3,
                    message: "Nombre debe tener al menos 3 caracteres",
                  },
                  maxLength: {
                    value: 20,
                    message: "Nombre debe tener como máximo 20 caracteres",
                  },
                })}
                autoFocus
                className={"form-control " + (errors?.Nombre ? "is-invalid" : "")}
              />
              {errors?.Nombre && touchedFields.Nombre && (
                <div className="invalid-feedback">
                  {errors?.Nombre?.message}
                </div>
              )}
            </div>
          </div>

          {/* campo Apellido */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Apellido">
                Apellido<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("Apellido", {
                  required: { value: true, message: "Apellido es requerido" },
                })}
                className={"form-control " + (errors?.Apellido ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">{errors?.Apellido?.message}</div>
            </div>
          </div>

          {/* campo NroDocumento */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="NroDocumento">
                NroDocumento<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="number"
                {...register("NroDocumento", {
                  required: { value: true, message: "NroDocumento es requerido" },
                })}
                className={"form-control " + (errors?.NroDocumento ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">{errors?.NroDocumento?.message}</div>
            </div>
          </div>

          {/* campo IdDeporte */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="IdDeporte">
                Deporte<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <select
                {...register("IdDeporte", {
                  required: { value: true, message: "Deporte es requerido" },
                })}
                className={"form-control " + (errors?.IdDeporte ? "is-invalid" : "")}
              >

                <option value="" key={1}></option>
                { Deportes?.map((x) => (
                  <option value={x.IdDeporte} key={x.IdDeporte}>
                    {x.Nombre}
                  </option>
                ))}
              </select>
              <div className="invalid-feedback">{errors?.IdDeporte?.message}</div>
            </div>
          </div>

          {/* campo FechaNacimiento */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="FechaNacimiento">
                Fecha de Nacimiento<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="date"
                {...register("FechaNacimiento", {
                  required: {
                    value: true,
                    message: "Fecha de Nacimiento es requerido",
                  },
                  validate: {
                    isLessThanCurrentDate: (value) => {
                      const selectedDate = new Date(value);
                      const currentDate = new Date();
                      return selectedDate < currentDate || "La fecha de nacimiento debe ser menor a la fecha actual";
                    },
                  },
                })}
                className={"form-control" + (errors?.FechaNacimiento ? " is-invalid" : "")}
              />
              <div className="invalid-feedback">{errors?.FechaNacimiento?.message}</div>
            </div>
          </div>
          
          {/* campo Club asociado */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="ClubAsociado">
                Club Asociado<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("ClubAsociado")}
                className={"form-control " + (errors?.ClubAsociado ? "is-invalid" : "")}
              />
              <div className="invalid-feedback">{errors?.ClubAsociado?.message}</div>
            </div>
          </div>

          {/* campo Activo */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Activo">
                Activo<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <select
                {...register("Activo")}
                className="form-control"
                disabled
              >
                <option value={null}></option>
                <option value={false}>NO</option>
                <option value={true}>SI</option>
              </select>
            </div>
          </div>
        </fieldset>

        {/* Botones Grabar, Cancelar/Volver */}
        <hr />
        <div className="row justify-content-center">
          <div className="col text-center botones">
            {AccionABMC !== "C" && (
              <button type="submit" className="btn btn-primary">
                <i className="fa fa-check"></i> Grabar
              </button>
            )}
            <button
              type="button"
              className="btn btn-warning"
              onClick={() => Volver()}
            >
              <i className="fa fa-undo"></i>
              {AccionABMC === "C" ? " Volver" : " Cancelar"}
            </button>
          </div>
        </div>

        {/* texto: Revisar los datos ingresados... */}
        {!isValid && isSubmitted && (
          <div className="row alert alert-danger mensajesAlert">
            <i className="fa fa-exclamation-sign"></i>
            Revisar los datos ingresados...
          </div>
        )}
      </div>
    </form>
  );
}
