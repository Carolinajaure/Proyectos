import React, { useState, useEffect } from "react";
import { medicosJWTService } from "../../services/medicosJWT.service";

function MedicosJWT() {
  const tituloPagina = "Medicos JWT (solo para admintradores)";
  const [medicos, setMedicos] = useState(null);

  // cargar al iniciar el componente, solo una vez
  useEffect(() => {
    BuscarMedicosJWT();
  }, []);

  async function BuscarMedicosJWT() {
     try {
      let data = await medicosJWTService.Buscar();
      setMedicos(data);
    } catch (error) {
      console.log("error al buscar datos en el servidor!")
    }
  }
  return (
        <>
        <div className="tituloPagina">{tituloPagina}</div>
        <table className="table table-bordered table-striped">
            <thead>
                <tr>
                    <th style={{ width: "20%" }}>IdMedico</th>
                    <th style={{ width: "50%" }}>Nombre</th>
                </tr>
            </thead>
            <tbody>
                {medicos &&
                    medicos.map((especialidades) => (
                    <tr key={especialidades.IdMedico}>
                        <td>{especialidades.IdMedico}</td>
                        <td>{especialidades.Nombre}</td>
                    </tr>
                    ))}
            </tbody>
        </table>
    </>
);
}
MedicosJWT.NombreComponenteNoOfuscado = "MedicosJWT";
export { MedicosJWT };