import React, { useState, useEffect } from "react";
import { deportistasJWTService } from "../../services/deportistasJWT.service";

function DeportistasJWT() {
  const tituloPagina = "Deportistas JWT (solo para admintradores)";
  const [deportistas, setDeportistas] = useState(null);

  // cargar al iniciar el componente, solo una vez
  useEffect(() => {
    BuscarDeportistasJWT();
  }, []);

  async function BuscarDeportistasJWT() {
     try {
      let data = await deportistasJWTService.Buscar();
      setDeportistas(data);
    } catch (error) {
      console.log("error al buscar datos en el servidor!")
    }
  }
  return (
        <>
        <div className="tituloPagina">{tituloPagina}</div>
        <table className="table table-bordered table-striped">
            <thead>
                <tr>
                    <th style={{ width: "20%" }}>IdDeportista</th>
                    <th style={{ width: "50%" }}>Nombre</th>
                    <th style={{ width: "50%" }}>Apellido</th>
                </tr>
            </thead>
            <tbody>
                {deportistas &&
                    deportistas.map((deporte) => (
                    <tr key={deporte.IdDeportista}>
                        <td>{deporte.IdDeportista}</td>
                        <td>{deporte.Nombre}</td>
                        <td>{deporte.Apellido}</td>
                    </tr>
                    ))}
            </tbody>
        </table>
    </>
);
}
DeportistasJWT.NombreComponenteNoOfuscado = "DeportistasJWT";
export { DeportistasJWT };