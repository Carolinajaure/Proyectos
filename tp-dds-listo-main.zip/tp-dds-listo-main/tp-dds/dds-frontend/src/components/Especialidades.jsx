import {useState, useEffect} from 'react';
import { especialidadMockService } from '../services/especialidades-mock.service.js';
function Especialidades() {
  const tituloPagina = 'Especialidades';
  const [especialidades, setEspecialidades] = useState(null);
  // cargar al montar el componente (solo una vez)
  useEffect(() => {
    BuscarEspecialidades();
  }, []);
  async function BuscarEspecialidades() {
    let data = await especialidadMockService.Buscar();
    setEspecialidades(data);
  };
  return (
    <div>
      <div className="tituloPagina">{tituloPagina}</div>
      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            <th style={{ width: "40%" }}>IdEspecialidad</th>
            <th style={{ width: "60%" }}>Nombre</th>
          </tr>
        </thead>
        <tbody>
          {especialidades &&
            especialidades.map((especialidad) => (
              <tr key={especialidad.IdEspecialidad}>
                <td>{especialidad.IdEspecialidad}</td>
                <td>{especialidad.Nombre}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}
export {Especialidades};