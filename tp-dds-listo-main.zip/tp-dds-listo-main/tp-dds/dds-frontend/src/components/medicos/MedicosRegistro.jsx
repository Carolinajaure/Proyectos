import React from "react";
import { useForm } from "react-hook-form";

export default function MedicosRegistro({
  AccionABMC,
  Especialidades,
  Item,
  Grabar,
  Volver,
}) {
  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields, isValid, isSubmitted },
  } = useForm({ values: Item });
  const onSubmit = (data) => {
    Grabar(data);
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="container-fluid">

        <fieldset disabled={AccionABMC === "C"}>

          {/* campo Nombre */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Nombre">
                Nombre<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("Nombre", {
                  required: { value: true, message: "Nombre es requerido" },
                  minLength: {
                    value: 4,
                    message: "Nombre debe tener al menos 4 caracteres",
                  },
                  maxLength: {
                    value: 55,
                    message: "Nombre debe tener como máximo 55 caracteres",
                  },
                })}
                autoFocus
                className={
                  "form-control " + (errors?.Nombre ? "is-invalid" : "")
                }
              />
              {errors?.Nombre && touchedFields.Nombre && (
                <div className="invalid-feedback">
                  {errors?.Nombre?.message}
                </div>
              )}
            </div>
          </div>

          {/* campo Apellido */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Apellido">
                Apellido<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("Apellido", {
                  required: { value: true, message: "Apellido es requerido" },
                  minLength: {
                    value: 4,
                    message: "Apellido debe tener al menos 4 caracteres",
                  },
                  maxLength: {
                    value: 55,
                    message: "Apellido debe tener como máximo 55 caracteres",
                  },
                })}
                className={
                  "form-control " + (errors?.Apellido ? "is-invalid" : "")
                }
              />
              {errors?.Apellido && touchedFields.Apellido && (
                <div className="invalid-feedback">
                  {errors?.Apellido?.message}
                </div>
              )}
            </div>
          </div>

          {/* campo Matricula */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Matricula">
                Matricula<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="number"
                {...register("Matricula", {
                  required: { value: true, message: "Matricula es requerida" },
                })}
                className={
                  "form-control " + (errors?.Matricula ? "is-invalid" : "")
                }
              />
              {errors?.Matricula && touchedFields.Matricula && (
                <div className="invalid-feedback">
                  {errors?.Matricula?.message}
                </div>
              )}
            </div>
          </div>

           {/* campo IdEspecialidad */}
           <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="IdEspecialidad">
                Especialidad<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <select
                {...register("IdEspecialidad", {
                  required: { value: true, message: "Especialidad es requerida" },
                })}
                className={
                  "form-control " + (errors?.IdEspecialidad ? "is-invalid" : "")
                }
              >
                <option value="" key={0}></option>
                {Especialidades?.map((x) => (
                  <option value={x.IdEspecialidad} key={x.IdEspecialidad}>
                    {x.Nombre}
                  </option>
                ))}
              </select>
              {errors?.IdEspecialidad && touchedFields.IdEspecialidad && (
                <div className="invalid-feedback">
                  {errors?.IdEspecialidad?.message}
                </div>
              )}
            </div>
          </div>

          {/* campo Nacionalidad */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Nacionalidad">
                Nacionalidad<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="text"
                {...register("Nacionalidad", {
                  required: { value: true, message: "Nacionalidad es requerida" },
                  minLength: {
                    value: 2,
                    message: "Nacionalidad debe tener al menos 2 caracteres",
                  },
                  maxLength: {
                    value: 55,
                    message: "Nacionalidad debe tener como máximo 55 caracteres",
                  },
                })}
                className={
                  "form-control " + (errors?.Nacionalidad ? "is-invalid" : "")
                }
              />
              {errors?.Nacionalidad && touchedFields.Nacionalidad && (
                <div className="invalid-feedback">
                  {errors?.Nacionalidad?.message}
                </div>
              )}
            </div>
          </div>

          {/* campo FechaNacimiento */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="FechaNacimiento">
                Fecha de Nacimiento<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="date"
                {...register("FechaNacimiento", {
                  required: { value: true, message: "Fecha de Nacimiento es requerida" },
                  validate: {
                    isLessThanCurrentDate: (value) => {
                      const selectedDate = new Date(value);
                      const currentDate = new Date();
                      return selectedDate < currentDate || "La fecha de nacimiento debe ser menor a la fecha actual";
                    },
                  },
                })}
                className={
                  "form-control " + (errors?.FechaNacimiento ? "is-invalid" : "")
                }
              />
              {errors?.FechaNacimiento && touchedFields.FechaNacimiento && (
                <div className="invalid-feedback">
                  {errors?.FechaNacimiento?.message}
                </div>
              )}
            </div>
          </div>

          {/* campo Activo */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Activo">
                Activo<span className="text-danger">*</span>:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <select
                {...register("Activo")}
                className="form-control"
                disabled
              >
                <option value={null}></option>
                <option value={false}>NO</option>
                <option value={true}>SI</option>
              </select>
            </div>
          </div>

          {/* campo Telefono */}
          <div className="row">
            <div className="col-sm-4 col-md-3 offset-md-1">
              <label className="col-form-label" htmlFor="Telefono">
                Telefono:
              </label>
            </div>
            <div className="col-sm-8 col-md-6">
              <input
                type="number"
                {...register("Telefono", {
                  minLength: {
                    value: 7,
                    message: "Telefono debe tener al menos 7 caracteres",
                  },
                  maxLength: {
                    value: 15,
                    message: "Telefono debe tener como máximo 15 caracteres",
                  },
                })}
                className={
                  "form-control " + (errors?.Telefono ? "is-invalid" : "")
                }
              />
              {errors?.Telefono && touchedFields.Telefono && (
                <div className="invalid-feedback">
                  {errors?.Telefono?.message}
                </div>
              )}
            </div>
          </div>

        </fieldset>

        {/* Botones Grabar, Cancelar/Volver' */}
        <hr />
        <div className="row justify-content-center">
          <div className="col text-center botones">
            {AccionABMC !== "C" && (
              <button type="submit" className="btn btn-primary">
                <i className="fa fa-check"></i> Grabar
              </button>
            )}
            <button
              type="button"
              className="btn btn-warning"
              onClick={() => Volver()}
            >
              <i className="fa fa-undo"></i>
              {AccionABMC === "C" ? " Volver" : " Cancelar"}
            </button>
          </div>
        </div>

        {/* texto: Revisar los datos ingresados... */}
        {!isValid && isSubmitted && (
          <div className="row alert alert-danger mensajesAlert">
            <i className="fa fa-exclamation-sign"></i>
            Revisar los datos ingresados...
          </div>
        )}
      </div>
    </form>
  );
}