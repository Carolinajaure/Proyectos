import {useState, useEffect} from 'react';
import { deportesMockService } from '../services/deportes-mock.service';
function Deportes() {
  const tituloPagina = 'Deportes';
  const [deportes, setDeportes] = useState(null);
  // cargar al montar el componente (solo una vez)
  useEffect(() => {
    BuscarDeportes();
  }, []);
  async function BuscarDeportes() {
    let data = await deportesMockService.Buscar();
    setDeportes(data);
  };
  return (
    <div>
      <div className="tituloPagina">{tituloPagina}</div>
      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            <th style={{ width: "40%" }}>IdDeporte</th>
            <th style={{ width: "60%" }}>Nombre</th>
          </tr>
        </thead>
        <tbody>
          {deportes &&
            deportes.map((deporte) => (
              <tr key={deporte.IdDeporte}>
                <td>{deporte.IdDeporte}</td>
                <td>{deporte.Nombre}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}
export {Deportes};
