const urlServidor = "http://localhost:3000"
const urlResourceDeportistas = urlServidor + "/api/deportistas";
const urlResourceDeportes = urlServidor + "/api/deportes";
const urlResourceDeportistasJWT = urlServidor + "/api/deportistasJWT";
const urlResourceMedicos = urlServidor + "/api/medicos";
const urlResourceEspecialidades = urlServidor + "/api/especialidades";
const urlResourceMedicosJWT = urlServidor + "/api/medicosJWT";
const urlResourceTorneos = urlServidor + "/api/torneos";
const urlResourceTorneosJWT = urlServidor + "/api/torneosJWT";


export const config = {
    urlServidor,
    urlResourceDeportistas,
    urlResourceDeportes,
    urlResourceDeportistasJWT,
    urlResourceMedicos,
    urlResourceEspecialidades,
    urlResourceMedicosJWT,
    urlResourceTorneos,
    urlResourceTorneosJWT
}
