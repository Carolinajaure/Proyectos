import "./App.css";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import {Inicio} from "./components/Inicio";
import {Deportes} from "./components/Deportes";
import {Menu} from "./components/Menu";
import { DeportistasJWT } from "./components/deportistasJWT/DeportistasJWT";
import {RequireAuth} from "./components/RequiereAuth" ;
import { Login } from "./components/login/Login";
import { Footer } from "./components/Footer";
import { ModalDialog } from "./components/ModalDialog";
import { Deportistas } from "./components/deportistas/Deportistas";
import {Especialidades} from "./components/Especialidades";
import { MedicosJWT } from "./components/medicosJWT/MedicosJWT";
import { Medicos } from "./components/medicos/Medicos";
import {Torneos} from "./components/torneos/Torneos";
import {TorneosJWT} from "./components/torneosJWT/TorneosJWT";
function App() {
  return (
    <>
      <BrowserRouter>
      <ModalDialog/>
        <Menu />
        <div className="divBody">
        <Routes>
          <Route path="/inicio" element={<Inicio />} />
          <Route path="/deportes" element={<Deportes />} />
          <Route path="/deportistas" element={<Deportistas />} />
          <Route path="/especialidades" element={<Especialidades />} />
          <Route path= "/medicos" element={<Medicos/>}/>
          <Route path="/torneos" element={<Torneos/>}/>
          <Route
            path="/torneosjwt"
            element={
              <RequireAuth>
                <TorneosJWT />
              </RequireAuth>
            }></Route>
          <Route
            path="/medicosjwt"
            element={
              <RequireAuth>
                <MedicosJWT />
              </RequireAuth>
            }></Route>
          <Route
            path="/deportistasjwt"
            element={
              <RequireAuth>
                <DeportistasJWT />
              </RequireAuth>
            }
          />
          <Route path="/login/:componentFrom" element={<Login />} />
          <Route path="*" element={<Navigate to="/inicio" replace />} />
        </Routes>
        </div>
        <Footer />
      </BrowserRouter>
    </>
  );
}
export default App;
