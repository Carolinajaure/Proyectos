import {config} from "../config";
import httpService from "./http.service";
const urlResource = "/api/medicosJWT";


async function Buscar(Nombre, Activo, Pagina) {
  const resp = await httpService.get(urlResource, {
    params: { Nombre, Activo, Pagina },
  });
  return resp.data;
}


async function BuscarPorId(item) {
  const resp = await httpService.get(urlResource + "/" + item.IdMedico);
  return resp.data;
}


async function ActivarDesactivar(item) {
  await httpService.delete(urlResource + "/" + item.IdMedico);
}


async function Grabar(item) {
  if (item.IdMedico === 0) {
    await httpService.post(urlResource, item);
  } else {
    await httpService.put(urlResource + "/" + item.IdMedico, item);
  }
}


export const medicosJWTService = {
  Buscar,BuscarPorId,ActivarDesactivar,Grabar
};