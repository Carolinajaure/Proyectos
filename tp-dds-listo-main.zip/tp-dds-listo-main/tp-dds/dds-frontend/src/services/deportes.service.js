
import httpService from "./http.service";
const urlResource = "/api/deportes";

async function Buscar() {
  const resp = await httpService.get(urlResource);
  return resp.data;
}
export const deportesService = {
  Buscar
};
