import axios from "axios";
import httpService from "./http.service";
const urlResource = "/api/especialidades";

async function Buscar() {
  try {
    const resp = await httpService.get(urlResource);
    return resp.data;
  } catch (error) {
    // Manejo del error
    console.error("Ocurrió un error al realizar la solicitud:", error);
    // Puedes decidir qué hacer con el error, por ejemplo, devolver un valor predeterminado o lanzar una excepción
    // return valorPredeterminado; // Opción 1: Devolver un valor predeterminado
    throw error; // Opción 2: Lanzar la excepción para que sea manejada por el llamador
  }
}

export const especialidadesService = {
  Buscar
};