import {config} from "../config";
import httpService from "./http.service";

const urlResourceDeportistas = "/api/deportistasJWT";




const urlResource = urlResourceDeportistas;


async function Buscar(Nombre, Activo, Pagina) {
  const resp = await httpService.get(urlResource, {
    params: { Nombre, Activo, Pagina },
  });
  return resp.data;
}


async function BuscarPorId(item) {
  const resp = await httpService.get(urlResource + "/" + item.IdDeportista);
  return resp.data;
}


async function ActivarDesactivar(item) {
  await httpService.delete(urlResource + "/" + item.IdDeportista);
}


async function Grabar(item) {
  if (item.IdDeportista === 0) {
    await httpService.post(urlResource, item);
  } else {
    await httpService.put(urlResource + "/" + item.IdDeportista, item);
  }
}


export const deportistasJWTService = {
  Buscar,BuscarPorId,ActivarDesactivar,Grabar
};
