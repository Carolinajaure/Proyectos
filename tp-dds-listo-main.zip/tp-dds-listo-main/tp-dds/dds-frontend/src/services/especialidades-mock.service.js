import arrayEspecialidades from '../datos-mock/especialidades-mock';
async function Buscar() {
     return arrayEspecialidades;
}
async function BuscarPorId(IdEspecialidad) {
      return arrayEspecialidades.find((especialidad) => especialidad.IdEspecialidad === IdEspecialidad);
}
async function Agregar(especialidad) {
    especialidad.IdEspecialidad = arrayEspecialidades.length + 1;  // simula autoincremental
    arrayEspecialidades.push(especialidad);
}
async function Modificar(especialidad) {
    let especialidadEncontrada = arrayEspecialidades.find((especialidadfind) => especialidadfind.IdEspecialidad === especialidad.IdEspecialidad);
    if (especialidadEncontrada) {
        especialidadEncontrada.Nombre = especialidad.Nombre;
    }
}
async function Eliminar(IdEspecialidad){
    let especialidadEncontrada = arrayEspecialidades.find((especialidadfind) => especialidadfind.IdEspecialidad === IdEspecialidad);
    if (especialidadEncontrada) {
        arrayEspecialidades.splice(arrayEspecialidades.indexOf(especialidadEncontrada), 1);
    }
}
export const especialidadMockService = {
    Buscar, BuscarPorId, Agregar, Modificar, Eliminar
};