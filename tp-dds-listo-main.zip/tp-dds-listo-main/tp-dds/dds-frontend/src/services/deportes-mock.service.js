import arrayDeporte from '../datos-mock/deportes-mock';
async function Buscar() {
     return arrayDeporte;
}
async function BuscarPorId(IdDeporte) {
      return arrayDeporte.find((deporte) => deporte.IdDeporte === IdDeporte);
}
async function Agregar(deporte) {
    deporte.IdDeporte = arrayDeporte.length + 1;  // simula autoincremental
    arrayDeporte.push(deporte);
}
async function Modificar(deporte) {
    let deporteEncontrado = arrayDeporte.find((deportefind) => deportefind.IdDeporte === deporte.IdDeporte);
    if (deporteEncontrado) {
        deporteEncontrado.Nombre = deporte.Nombre;
    }
}
async function Eliminar(IdDeporte){
    let deporteEncontrado = arrayDeporte.find((deportefind) => deportefind.IdDeporte === IdDeporte);
    if (deporteEncontrado) {
        arrayDeporte.splice(arrayDeporte.indexOf(deporteEncontrado), 1);
    }
}
export const deportesMockService = {
    Buscar, BuscarPorId, Agregar, Modificar, Eliminar
};
